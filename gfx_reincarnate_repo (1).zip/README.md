# GFX Reincarnate (AML PSDK, GTA SA)
Build otomatis lewat GitHub Actions. Buka tab **Actions** -> run terbaru -> unduh artifact **GFXReincarnate-so**.
- `libGFXReincarnate.so`   : 32-bit (armeabi-v7a, GTA SA v2.00)
- `libGFXReincarnate64.so` : 64-bit (arm64-v8a, GTA SA v2.10)
- `configs/*.ini` : konfigurasi HD siap pakai (ganti nama jadi `net.psdk.gfxreincarnate.ini`)
