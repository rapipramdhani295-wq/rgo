// GFX Reincarnate-style plugin for GTA SA (AML PSDK)
// Supports: GTA SA v2.00 (ARM32) and v2.10 (ARM64)
//
// What it does (every frame, right after CTimeCycle::Update):
//   - color grading: saturation / contrast / warmth on sky, clouds, sun, post-fx colours
//   - ambient + directional light boost
//   - fog / far clip / LOD distance
//   - shadow strength
//   - built-in post effects: radiosity (bloom-like glow), highlight, grain
// All values come from an .ini created by AML on first run (see cfg below).

#include <float.h> // FLT_EPSILON (used by aml-psdk Vector.h)
#include <mod/amlmod.h>
#include <mod/logger.h>
#include <mod/config.h>

// Do not include all like a crazy! It will slowdown the mod loading!
#include <aml-psdk/game_sa/other/TimeCycle.h>
#include <aml-psdk/game_sa/engine/PostEffects.h>
#include <aml-psdk/game_sa/engine/Renderer.h>
#include <aml-psdk/game_sa/engine/Draw.h>
#include <aml-psdk/game_sa/engine/CustomCarEnvMapPipeline.h>
#include <aml-psdk/game_sa/other/Weather.h>
#include <aml-psdk/renderware/RwTexture.h>
#include <aml-psdk/renderware/RwRaster.h>
#include <aml-psdk/renderware/RwRender.h>

MYMODCFG(net.psdk.gfxreincarnate, GFX Reincarnate, 1.0, Author)

#if !defined(IAML_VER) || IAML_VER < 01040100
    #error "You need to update your MOD folder to 1.4.1!"
#endif

// ---------------------------------------------------------------- settings
struct GfxSettings
{
    bool  enabled;

    // grading
    float saturation;     // 1.0 = vanilla
    float contrast;       // 1.0 = vanilla
    float warmth;         // -0.2 .. 0.2  (+ = warmer, - = colder)
    float skySaturation;
    float cloudBrightness;

    // lighting
    float ambientMult;
    float directionalMult;
    float shadowMult;

    // distance
    float farClipMult;
    float fogStartMult;
    float lodScale;       // 0 = leave game value

    // built-in post effects
    bool  radiosity;
    int   radiosityIntensity;
    int   radiosityLimit;
    int   radiosityFilterPasses;
    int   radiosityRenderPasses;
    bool  highlight;
    int   highlightStrength;
    bool  grain;
    int   grainStrength;
    float postFxAlphaMult;

    // clarity / reflections
    float wetRoads;       // 0 = off. Minimum road wetness (0..1): glossy road + light reflections
    float carShine;       // multiplier on car env-map reflection strength (1 = vanilla)
    float carSpec;        // multiplier on car specular highlights (1 = vanilla)
    bool  trilinear;      // trilinear filtering on textures that have mipmaps (sharper at distance)
} g_Cfg;

// ---------------------------------------------------------------- presets
// Order matches GfxSettings fields below.
enum ePreset { PRESET_CUSTOM = 0, PRESET_PERFORMANCE, PRESET_HD, PRESET_HD_ULTRA, PRESET_CINEMATIC, PRESET_VIVID, PRESET_COUNT };

static const char* g_PresetNames[PRESET_COUNT] =
    { "Custom (use values from .ini)", "Performance", "HD", "HD Ultra", "Cinematic", "Vivid" };

//                          sat   con   warm  skySat cloud | amb   dir   shad | far   fog   lod  | rad  radI radL fP rP | hl  hlS | grain gS | pfx  | wet  shine spec trilin
static const GfxSettings g_Presets[PRESET_COUNT] =
{
    /* Custom      */ {},
    /* Performance */ { true, 1.10f,1.04f,0.02f,1.10f,1.05f, 1.05f,1.05f,1.00f, 1.00f,1.00f,1.00f, false,0,0,0,0, false,0, false,0, 1.00f, 0.00f,1.00f,1.00f,false },
    /* HD          */ { true, 1.18f,1.08f,0.04f,1.25f,1.10f, 1.10f,1.10f,1.20f, 1.60f,1.60f,1.30f, true,30,100,2,2, true,16, false,0, 1.00f, 0.20f,1.50f,1.40f,false },
    /* HD Ultra    */ { true, 1.25f,1.12f,0.05f,1.35f,1.15f, 1.15f,1.15f,1.35f, 2.20f,2.20f,1.80f, true,45,120,3,3, true,24, false,0, 1.10f, 0.35f,1.90f,1.70f,true  },
    /* Cinematic   */ { true, 0.95f,1.18f,0.08f,1.05f,1.00f, 0.95f,1.20f,1.40f, 1.80f,1.80f,1.40f, true,38,100,2,2, true,12, true,6,  1.20f, 0.30f,1.60f,1.40f,false },
    /* Vivid       */ { true, 1.40f,1.10f,0.02f,1.50f,1.20f, 1.15f,1.10f,1.10f, 1.60f,1.60f,1.30f, true,35,110,2,2, true,20, false,0, 1.00f, 0.15f,1.60f,1.50f,false },
};

static void LoadSettingsInner();
static void LoadSettings()
{
    LoadSettingsInner();
    if(cfg->GetBool("TestMode", false, "Graphics"))
    {
        // Obvious on-screen proof that the plugin works: very strong colours.
        g_Cfg.enabled = true;
        g_Cfg.saturation = 2.2f; g_Cfg.skySaturation = 2.5f; g_Cfg.contrast = 1.35f;
        g_Cfg.warmth = 0.18f; g_Cfg.ambientMult = 1.5f; g_Cfg.directionalMult = 1.5f;
        g_Cfg.wetRoads = 0.8f;
        logger->Info("TestMode ON (extreme colours)");
    }
}

static void LoadSettingsInner()
{
    cfg->Bind("Preset", 2, "Graphics"); // 1=Performance 2=HD 3=HD Ultra 4=Cinematic 5=Vivid 0=Custom
    int preset = cfg->GetInt("Preset", 2, "Graphics");
    if(preset < 0 || preset >= PRESET_COUNT) preset = PRESET_HD;
    bool enabled = cfg->GetBool("Enabled", true, "Graphics");

    if(preset != PRESET_CUSTOM)
    {
        g_Cfg = g_Presets[preset];
        g_Cfg.enabled = enabled;
        logger->Info("Preset: %s", g_PresetNames[preset]);
        cfg->Save();
        return;
    }

    // ---- Custom: every value is read from the .ini
    const char* S = "Graphics";
    g_Cfg.enabled           = enabled;

    g_Cfg.saturation        = cfg->GetFloat("Saturation",         1.18f, S);
    g_Cfg.contrast          = cfg->GetFloat("Contrast",           1.08f, S);
    g_Cfg.warmth            = cfg->GetFloat("Warmth",             0.04f, S);
    g_Cfg.skySaturation     = cfg->GetFloat("SkySaturation",      1.25f, S);
    g_Cfg.cloudBrightness   = cfg->GetFloat("CloudBrightness",    1.10f, S);

    g_Cfg.ambientMult       = cfg->GetFloat("AmbientMult",        1.10f, S);
    g_Cfg.directionalMult   = cfg->GetFloat("DirectionalMult",    1.10f, S);
    g_Cfg.shadowMult        = cfg->GetFloat("ShadowStrengthMult", 1.20f, S);

    g_Cfg.farClipMult       = cfg->GetFloat("FarClipMult",        1.60f, S);
    g_Cfg.fogStartMult      = cfg->GetFloat("FogStartMult",       1.60f, S);
    g_Cfg.lodScale          = cfg->GetFloat("LODScale",           1.30f, S);

    const char* P = "PostEffects";
    g_Cfg.radiosity             = cfg->GetBool ("Radiosity",          true, P);
    g_Cfg.radiosityIntensity    = cfg->GetInt  ("RadiosityIntensity", 35,   P);
    g_Cfg.radiosityLimit        = cfg->GetInt  ("RadiosityLimit",     110,  P);
    g_Cfg.radiosityFilterPasses = cfg->GetInt  ("RadiosityFilterPasses", 2, P);
    g_Cfg.radiosityRenderPasses = cfg->GetInt  ("RadiosityRenderPasses", 2, P);
    g_Cfg.highlight             = cfg->GetBool ("Highlight",          true, P);
    g_Cfg.highlightStrength     = cfg->GetInt  ("HighlightStrength",  18,   P);
    g_Cfg.grain                 = cfg->GetBool ("Grain",              false, P);
    g_Cfg.grainStrength         = cfg->GetInt  ("GrainStrength",      8,    P);
    g_Cfg.postFxAlphaMult       = cfg->GetFloat("PostFxAlphaMult",    1.0f, P);

    const char* R = "Clarity";
    g_Cfg.wetRoads  = cfg->GetFloat("WetRoadsMin", 0.20f, R);
    g_Cfg.carShine  = cfg->GetFloat("CarReflectionMult", 1.50f, R);
    g_Cfg.carSpec   = cfg->GetFloat("CarSpecularMult",   1.40f, R);
    g_Cfg.trilinear = cfg->GetBool ("TrilinearFilter",   false, R);

    cfg->Save(); // writes defaults on first run
}

// ---------------------------------------------------------------- helpers
static inline float Clamp(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

// 0..255 integer colour channels (u16 in CColourSet)
static inline void GradeU16(u16& r, u16& g, u16& b, float sat, float contrast, float warmth)
{
    float fr = r, fg = g, fb = b;
    float lum = 0.299f * fr + 0.587f * fg + 0.114f * fb;
    fr = lum + (fr - lum) * sat;
    fg = lum + (fg - lum) * sat;
    fb = lum + (fb - lum) * sat;
    fr = (fr - 127.5f) * contrast + 127.5f;
    fg = (fg - 127.5f) * contrast + 127.5f;
    fb = (fb - 127.5f) * contrast + 127.5f;
    fr *= 1.0f + warmth;
    fb *= 1.0f - warmth;
    r = (u16)Clamp(fr, 0.0f, 255.0f);
    g = (u16)Clamp(fg, 0.0f, 255.0f);
    b = (u16)Clamp(fb, 0.0f, 255.0f);
}

// Float colours whose scale (0..1 or 0..255) differs between builds: detect it.
static inline float AutoMax(float a, float b, float c)
{
    float m = a > b ? a : b; if(c > m) m = c;
    return (m > 1.5f) ? 255.0f : 1.0f;
}
static inline void MulFloat3(float& r, float& g, float& b, float mult)
{
    float lim = AutoMax(r, g, b);
    r = Clamp(r * mult, 0.0f, lim);
    g = Clamp(g * mult, 0.0f, lim);
    b = Clamp(b * mult, 0.0f, lim);
}

// ---------------------------------------------------------------- the work
static void ApplyGraphics(CColourSet& cs)
{

    // --- sky / sun / clouds
    GradeU16(cs.m_nSkyTopRed,    cs.m_nSkyTopGreen,    cs.m_nSkyTopBlue,    g_Cfg.skySaturation, g_Cfg.contrast, g_Cfg.warmth * 0.5f);
    GradeU16(cs.m_nSkyBottomRed, cs.m_nSkyBottomGreen, cs.m_nSkyBottomBlue, g_Cfg.skySaturation, g_Cfg.contrast, g_Cfg.warmth);
    GradeU16(cs.m_nSunCoreRed,   cs.m_nSunCoreGreen,   cs.m_nSunCoreBlue,   g_Cfg.saturation,    1.0f,           g_Cfg.warmth);
    GradeU16(cs.m_nSunCoronaRed, cs.m_nSunCoronaGreen, cs.m_nSunCoronaBlue, g_Cfg.saturation,    1.0f,           g_Cfg.warmth);
    GradeU16(cs.m_nLowCloudsRed, cs.m_nLowCloudsGreen, cs.m_nLowCloudsBlue, g_Cfg.saturation,    g_Cfg.contrast, g_Cfg.warmth);
    GradeU16(cs.m_nFluffyCloudsBottomRed, cs.m_nFluffyCloudsBottomGreen, cs.m_nFluffyCloudsBottomBlue,
                                                                           g_Cfg.saturation,    g_Cfg.contrast, g_Cfg.warmth);
    if(g_Cfg.cloudBrightness != 1.0f)
    {
        cs.m_nLowCloudsRed   = (u16)Clamp(cs.m_nLowCloudsRed   * g_Cfg.cloudBrightness, 0, 255);
        cs.m_nLowCloudsGreen = (u16)Clamp(cs.m_nLowCloudsGreen * g_Cfg.cloudBrightness, 0, 255);
        cs.m_nLowCloudsBlue  = (u16)Clamp(cs.m_nLowCloudsBlue  * g_Cfg.cloudBrightness, 0, 255);
    }

    // --- lighting
    MulFloat3(cs.m_fAmbientRed,     cs.m_fAmbientGreen,     cs.m_fAmbientBlue,     g_Cfg.ambientMult);
    MulFloat3(cs.m_fAmbientRed_Obj, cs.m_fAmbientGreen_Obj, cs.m_fAmbientBlue_Obj, g_Cfg.ambientMult);
    MulFloat3(cs.m_fDirectionalRed, cs.m_fDirectionalGreen, cs.m_fDirectionalBlue, g_Cfg.directionalMult);

    // warm ambient/directional a little (sun feeling)
    cs.m_fDirectionalRed  *= 1.0f + g_Cfg.warmth;
    cs.m_fDirectionalBlue *= 1.0f - g_Cfg.warmth;

    // --- shadows
    cs.m_nShadowStrength      = (i16)Clamp(cs.m_nShadowStrength      * g_Cfg.shadowMult, 0, 255);
    cs.m_nLightShadowStrength = (i16)Clamp(cs.m_nLightShadowStrength * g_Cfg.shadowMult, 0, 255);
    cs.m_nPoleShadowStrength  = (i16)Clamp(cs.m_nPoleShadowStrength  * g_Cfg.shadowMult, 0, 255);

    // --- distance / fog
    cs.m_fFarClip  *= g_Cfg.farClipMult;
    cs.m_fFogStart *= g_Cfg.fogStartMult;

    // --- post-fx colour overlays (only intensity; colours stay game-authored)
    if(g_Cfg.postFxAlphaMult != 1.0f)
    {
        float lim1 = (cs.m_fPostFx1Alpha > 1.5f) ? 255.0f : 1.0f;
        float lim2 = (cs.m_fPostFx2Alpha > 1.5f) ? 255.0f : 1.0f;
        cs.m_fPostFx1Alpha = Clamp(cs.m_fPostFx1Alpha * g_Cfg.postFxAlphaMult, 0.0f, lim1);
        cs.m_fPostFx2Alpha = Clamp(cs.m_fPostFx2Alpha * g_Cfg.postFxAlphaMult, 0.0f, lim2);
    }

    // --- road reflections (wet look makes lights/sun reflect on asphalt)
    if(g_Cfg.wetRoads > 0.0f && CWeather::WetRoads < g_Cfg.wetRoads)
        CWeather::WetRoads = g_Cfg.wetRoads;

    // --- LOD
    if(g_Cfg.lodScale > 0.0f) CRenderer::ms_lodDistScale = g_Cfg.lodScale;

    // --- built-in post effects
    CPostEffects::m_bDisableAllPostEffect = false;

    CPostEffects::m_bRadiosity = g_Cfg.radiosity;
    if(g_Cfg.radiosity)
    {
        CPostEffects::m_RadiosityIntensity    = g_Cfg.radiosityIntensity;
        CPostEffects::m_RadiosityIntensityLimit = g_Cfg.radiosityLimit;
        CPostEffects::m_RadiosityFilterPasses = g_Cfg.radiosityFilterPasses;
        CPostEffects::m_RadiosityRenderPasses = g_Cfg.radiosityRenderPasses;
        CPostEffects::m_bRadiosityBypassTimeCycleIntensityLimit = true;
    }

    CPostEffects::m_bHilightEnable = g_Cfg.highlight;
    if(g_Cfg.highlight) CPostEffects::m_hilightStrength = g_Cfg.highlightStrength;

    CPostEffects::m_bGrainEnable = g_Cfg.grain;
    if(g_Cfg.grain) CPostEffects::m_grainStrength = g_Cfg.grainStrength;
}

// ---------------------------------------------------------------- hooks
// CTimeCycle::Update fills m_CurrentColours; we post-process the result.
// NOTE: the game rebuilds m_CurrentColours from scratch each frame, so the
// multipliers above do NOT accumulate.
// Some builds fill m_CurrentColours inside CalcColoursForPoint, others elsewhere,
// so we hook both and make sure the grading is applied exactly once per frame.
static bool g_bAppliedThisUpdate = false;
static bool g_bToastShown = false;

DECL_HOOKv(CTimeCycle__CalcColours, CVector point, CColourSet* set)
{
    CTimeCycle__CalcColours(point, set);
    if(g_Cfg.enabled && set && set == &(CColourSet&)CTimeCycle::m_CurrentColours)
    {
        ApplyGraphics(*set);
        g_bAppliedThisUpdate = true;
    }
}

DECL_HOOKv(CTimeCycle__Update)
{
    g_bAppliedThisUpdate = false;
    CTimeCycle__Update();
    if(g_Cfg.enabled && !g_bAppliedThisUpdate)
    {
        ApplyGraphics(CTimeCycle::m_CurrentColours);
    }
    if(!g_bToastShown)
    {
        g_bToastShown = true;
        logger->Info("Hook is running (CTimeCycle::Update called)");
        aml->ShowToast(false, "GFX Reincarnate aktif (%s)", BYBIT("32-bit", "64-bit"));
    }
}

// Car paint reflections: called once when a material gets its env/spec data.
// We only touch materials that already have a reflection (value > 0).
DECL_HOOK(RpMaterial*, CarMat__Setup, RpMaterial* material, void* data)
{
    RpMaterial* ret = CarMat__Setup(material, data);
    if(!ret || !g_Cfg.enabled) return ret;

    if(g_Cfg.carShine != 1.0f)
    {
        float v = CCustomCarEnvMapPipeline::GetFxEnvShininess(ret);
        if(v > 0.0f)
        {
            float lim = (v > 1.5f) ? 255.0f : 1.0f;
            CCustomCarEnvMapPipeline::SetFxEnvShininess(ret, Clamp(v * g_Cfg.carShine, 0.0f, lim));
        }
    }
    if(g_Cfg.carSpec != 1.0f)
    {
        float v = CCustomCarEnvMapPipeline::GetFxSpecSpecularity(ret);
        if(v > 0.0f)
            CCustomCarEnvMapPipeline::SetFxSpecSpecularity(ret, Clamp(v * g_Cfg.carSpec, 0.0f, 4.0f));
    }
    return ret;
}

// Sharper textures: trilinear ONLY if the raster really contains mip levels,
// otherwise GLES would render the texture black.
DECL_HOOK(RwTexture*, Tex__Read, const char* name, const char* mask)
{
    RwTexture* tex = Tex__Read(name, mask);
    if(tex && g_Cfg.enabled && g_Cfg.trilinear && tex->raster && (tex->raster->cFormat & 0x80))
    {
        tex->filterAddressing = (tex->filterAddressing & ~0xFFu) | (u32)rwFILTERLINEARMIPLINEAR;
    }
    return tex;
}

ON_MOD_LOAD()
{
    logger->SetTag("GFX Reincarnate");
    cfg->Init();
    LoadSettings();

    if(!g_Cfg.enabled)
    {
        logger->Info("Disabled in config");
        return;
    }

    HOOK(CTimeCycle__Update, CTimeCycle::Update);
    HOOK(CTimeCycle__CalcColours, CTimeCycle::CalcColoursForPoint);
    if(g_Cfg.carShine != 1.0f || g_Cfg.carSpec != 1.0f)
        HOOK(CarMat__Setup, CCustomCarEnvMapPipeline::CustomPipeMaterialSetup);
    if(g_Cfg.trilinear)
        HOOK(Tex__Read, RwTextureRead);
    logger->Info("Loaded (%s)", BYBIT("ARM32", "ARM64"));
}
