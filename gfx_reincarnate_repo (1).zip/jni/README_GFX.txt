GFX Reincarnate (AML PSDK) - cara build
1. Isi ndkpath.txt dengan lokasi Android NDK (kalau build pakai build.ps1), atau jalankan ndk-build di folder induk jni.
2. Build: ndk-build NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=jni/Android.mk NDK_APPLICATION_MK=jni/Application.mk
3. Hasil: libs/armeabi-v7a/libGFXReincarnate.so (32-bit) dan libs/arm64-v8a/libGFXReincarnate64.so (64-bit).
4. Salin .so sesuai arsitektur APK ke folder mod AML. Jangan tertukar.
5. Edit file .ini yang dibuat otomatis: Preset=1..5 (0=Custom).
