#ifndef RGO_H
#define RGO_H

// Realistic Graphics Overhaul (RGO) - settings shared between main.cpp and the post-process pipeline.

struct RGOSettings
{
    // [General]
    bool  enabled        = true;
    int   depthMode      = 0;      // 0 = standard OpenGL depth (-1..1), 1 = D3D style (0..1)
    bool  timeOfDayGrade = false;
    int   debugView      = 0;      // 0 = normal, 1 = show depth, 2 = show SSAO
    bool  splitCompare   = false;   // only the LEFT half of the screen gets the effect (compare with the right half)
    int   depthSource    = 0;      // 0 = auto, 1 = default framebuffer only, 2 = always the FBO bound at swap
    int   targetMode     = 0;      // 0 = process default framebuffer, 1 = process the FBO bound at swap time
    bool  distanceBoost  = true;   // farther / more detailed distant objects
    float lodScale       = 1.3f;   // CRenderer::ms_lodDistScale multiplier
    float lowLodScale    = 1.4f;   // CRenderer::ms_lowLodDistScale multiplier
    float drawDistScale  = 1.3f;   // CDraw::ms_fLODDistance multiplier
    bool  whiteTextures  = false;  // opaque textures (>= WhiteMinSize) become plain white: lightest mode
    int   whiteMinSize   = 256;
    bool  textureLite    = false;   // shrink big compressed textures while the game loads them (saves RAM/GPU)
    int   textureMaxSize = 256;    // textures larger than this lose their top mip level(s)
    bool  shaderDump     = false;   // phase 2: write the game's GLSL sources to RGO_shaders/
    bool  textureStats   = false;   // phase 2: log texture upload statistics
    bool  debugMarker    = false;   // small square top-left: blue = hook reached, green = pipeline ran

    // [SSAO]
    bool  ssao           = false;
    float ssaoRadius     = 1.5f;   // metres (view space)
    float ssaoIntensity  = 1.3f;
    float ssaoBias       = 0.04f;
    float ssaoFadeStart  = 60.0f;  // AO fades out between these distances
    float ssaoFadeEnd    = 140.0f;
    float ssaoStrength   = 0.92f;  // 0 = off, 1 = full multiply

    // [Bloom]
    bool  bloom          = false;
    float bloomThreshold = 0.75f;
    float bloomKnee      = 0.35f;
    float bloomIntensity = 0.18f;
    int   bloomLevels    = 3;

    // [SSR] screen-space reflections on upward-facing surfaces (roads, ground), stronger when wet
    bool  ssr            = false;
    float ssrStrength    = 0.9f;
    float ssrDry         = 0.25f;  // reflectivity when dry, 1.0 when raining / wet roads
    int   ssrSteps       = 16;     // max 32
    float ssrMaxDist     = 30.0f;
    float ssrThickness   = 0.8f;

    // [Atmosphere] depth fog tinted by time of day
    bool  fog            = false;
    float fogDensity     = 0.0035f;
    float fogStrength    = 0.45f;

    // [Color]
    float exposure       = 1.0f;
    float tonemapMix     = 0.0f;  // 0 = keep game look, 1 = full ACES
    float shadowLift     = 0.0f;  // 0 = off, higher = darker areas (houses, shade) get brighter
    float contrast       = 1.0f; 
    float saturation     = 1.0f;
    float vignette       = 0.0f; 
    float splitTone      = 0.0f;  // cool shadows / warm highlights (GTA IV look)

    // [Shadow] screen-space contact shadows from the sun (needs the sun on screen)
    bool  contactShadow  = false;
    float shadowStrength = 0.55f;
    float shadowLen      = 6.0f;   // metres traced towards the sun
    int   shadowSteps    = 12;     // max 16

    // [Volumetric] god rays from the sun
    bool  volumetric     = false;
    float volStrength    = 0.45f;
    bool  forceSun       = false;  // test: fake sun at a fixed spot so rays/glint/shadow always show
    float volDensity     = 0.9f;   // 0.3 .. 1.2, how far the rays reach across the screen

    // [SunGlint] sun reflection on roads / ground (strongest when driving towards the sun)
    bool  sunGlint       = false;
    float glintStrength  = 0.7f;

    // [Wet] wet look for roads
    float wetAmount      = 0.0f;   // 0 = real weather only, 1 = always soaked
    float wetDarken      = 0.0f;   // darkens ground a bit, like a wet road

    // [AA]
    bool  fxaa           = false;
    float sharpen        = 0.0f;
    float clarity        = 0.0f;   // local contrast: makes texture detail pop (HD look)
    float textureSmooth  = 0.0f;   // 0..1, softens texture noise but keeps edges (clean look)
};

extern RGOSettings g_RGO;

void RGO_OnSwapBuffers(void* eglDisplay, void* eglSurface); // call right before the real eglSwapBuffers
void RGO_Shutdown();
void RGOFileLog(const char* fmt, ...);   // appends to <android data path>/RGO_log.txt

#define RGO_LOGI(...) do { logger->Info(__VA_ARGS__); RGOFileLog(__VA_ARGS__); } while(0)
#define RGO_LOGE(...) do { logger->Error(__VA_ARGS__); RGOFileLog(__VA_ARGS__); } while(0)

#endif // RGO_H
