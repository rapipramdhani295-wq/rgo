// RGO - post-process pipeline (OpenGL ES 3.0+)
//
//   scene copy -> SSAO (half-res, depth based) -> bilateral blur
//              -> bloom (dual filter chain) -> composite (grade + tonemap) -> FXAA/sharpen -> screen
//
// Runs on the GL thread, right before eglSwapBuffers. See README for known limits (HUD is also processed).

#include <mod/amlmod.h>
#include <mod/logger.h>
#include <aml-psdk/game_sa/engine/Draw.h>
#include <aml-psdk/game_sa/other/Clock.h>
#include <aml-psdk/game_sa/other/Weather.h>

#include "rgo.h"
#include "rgo_gl.h"
#include "rgo_hook.h"

extern Logger* logger;

RGOSettings g_RGO;

// ------------------------------------------------------------------------------------------------
// GLSL
// ------------------------------------------------------------------------------------------------
static const char* kHead =
    "#version 300 es\n"
    "precision highp float;\n"
    "precision highp int;\n"
    "precision highp sampler2D;\n";

static const char* kVS =
    "out vec2 vUV;\n"
    "void main(){\n"
    "  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));\n"
    "  vUV = p;\n"
    "  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);\n"
    "}\n";

// uProj = (tanHalfFovX, tanHalfFovY, near, far), uMode = depth mode
static const char* kDepthLib =
    "uniform sampler2D uDepth;\n"
    "uniform vec4 uProj;\n"
    "uniform float uMode;\n"
    "float linZ(float d){\n"
    "  float n = uProj.z, f = uProj.w;\n"
    "  if (uMode < 0.5) { float z = d * 2.0 - 1.0; return 2.0 * n * f / (f + n - z * (f - n)); }\n"
    "  return n * f / (f - d * (f - n));\n"
    "}\n"
    "vec3 viewPos(vec2 uv){\n"
    "  float z = linZ(texture(uDepth, uv).r);\n"
    "  return vec3((uv * 2.0 - 1.0) * uProj.xy * z, z);\n"
    "}\n"
    "float ign(vec2 p){ return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }\n";

static const char* kFS_SSAO =
    "in vec2 vUV; out vec4 oC;\n"
    "uniform vec2 uPx;          // 1 / full-res size\n"
    "uniform vec4 uAO;          // radius, intensity, bias, -\n"
    "uniform vec2 uFade;        // fade start / end distance\n"
    "const int N = 12;\n"
    "void main(){\n"
    "  float d0 = texture(uDepth, vUV).r;\n"
    "  if (d0 >= 0.99999) { oC = vec4(1.0); return; }\n"
    "  vec3 p  = viewPos(vUV);\n"
    "  vec3 pr = viewPos(vUV + vec2(uPx.x, 0.0)), pl = viewPos(vUV - vec2(uPx.x, 0.0));\n"
    "  vec3 pu = viewPos(vUV + vec2(0.0, uPx.y)), pd = viewPos(vUV - vec2(0.0, uPx.y));\n"
    "  vec3 dx = abs(pr.z - p.z) < abs(pl.z - p.z) ? pr - p : p - pl;\n"
    "  vec3 dy = abs(pu.z - p.z) < abs(pd.z - p.z) ? pu - p : p - pd;\n"
    "  vec3 n = -normalize(cross(dx, dy));\n"
    "  float a = ign(gl_FragCoord.xy) * 6.2831853;\n"
    "  vec3 rv = vec3(cos(a), sin(a), 0.0);\n"
    "  vec3 t = normalize(rv - n * dot(rv, n));\n"
    "  vec3 b = cross(n, t);\n"
    "  float occ = 0.0;\n"
    "  for (int i = 0; i < N; i++) {\n"
    "    float s  = (float(i) + 0.5) / float(N);\n"
    "    float ph = float(i) * 2.399963;\n"
    "    float r  = sqrt(max(1.0 - s * s, 0.0));\n"
    "    vec3 k   = vec3(r * cos(ph), r * sin(ph), s) * mix(0.12, 1.0, s * s);\n"
    "    vec3 sp  = p + (t * k.x + b * k.y + n * k.z) * uAO.x;\n"
    "    if (sp.z <= 0.01) continue;\n"
    "    vec2 uv  = (sp.xy / (sp.z * uProj.xy)) * 0.5 + 0.5;\n"
    "    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) continue;\n"
    "    float sz = linZ(texture(uDepth, uv).r);\n"
    "    float rc = smoothstep(0.0, 1.0, uAO.x / max(abs(p.z - sz), 0.0001));\n"
    "    occ += (sz < sp.z - uAO.z ? 1.0 : 0.0) * rc;\n"
    "  }\n"
    "  float ao = 1.0 - clamp(occ / float(N) * uAO.y, 0.0, 1.0);\n"
    "  ao = mix(ao, 1.0, smoothstep(uFade.x, uFade.y, p.z));\n"
    "  oC = vec4(ao, ao, ao, 1.0);\n"
    "}\n";

static const char* kFS_Blur =
    "in vec2 vUV; out vec4 oC;\n"
    "uniform sampler2D uAOTex;\n"
    "uniform vec2 uDir;   // texel step along blur axis (AO resolution)\n"
    "void main(){\n"
    "  float c  = texture(uAOTex, vUV).r;\n"
    "  float zc = linZ(texture(uDepth, vUV).r);\n"
    "  float sum = c, wsum = 1.0;\n"
    "  for (int i = -4; i <= 4; i++) {\n"
    "    if (i == 0) continue;\n"
    "    vec2 uv = vUV + uDir * float(i);\n"
    "    float v = texture(uAOTex, uv).r;\n"
    "    float z = linZ(texture(uDepth, uv).r);\n"
    "    float w = exp(-float(i * i) / 8.0) / (1.0 + abs(z - zc) / max(zc, 0.1) * 80.0);\n"
    "    sum += v * w; wsum += w;\n"
    "  }\n"
    "  float r = sum / wsum;\n"
    "  oC = vec4(r, r, r, 1.0);\n"
    "}\n";

static const char* kFS_Prefilter =
    "in vec2 vUV; out vec4 oC;\n"
    "uniform sampler2D uSrc;\n"
    "uniform vec2 uTexel;\n"
    "uniform vec2 uThr;   // threshold, knee\n"
    "void main(){\n"
    "  vec3 c = texture(uSrc, vUV + uTexel * vec2(-1.0, -1.0)).rgb\n"
    "         + texture(uSrc, vUV + uTexel * vec2( 1.0, -1.0)).rgb\n"
    "         + texture(uSrc, vUV + uTexel * vec2(-1.0,  1.0)).rgb\n"
    "         + texture(uSrc, vUV + uTexel * vec2( 1.0,  1.0)).rgb;\n"
    "  c *= 0.25;\n"
    "  float l = max(c.r, max(c.g, c.b));\n"
    "  float soft = clamp(l - uThr.x + uThr.y, 0.0, 2.0 * uThr.y);\n"
    "  soft = soft * soft / (4.0 * uThr.y + 0.0001);\n"
    "  float k = max(soft, l - uThr.x) / max(l, 0.0001);\n"
    "  oC = vec4(c * k, 1.0);\n"
    "}\n";

static const char* kFS_Down =
    "in vec2 vUV; out vec4 oC;\n"
    "uniform sampler2D uSrc;\n"
    "uniform vec2 uTexel;  // 1 / source size\n"
    "void main(){\n"
    "  vec3 s = texture(uSrc, vUV).rgb * 4.0;\n"
    "  s += texture(uSrc, vUV + uTexel * vec2(-1.0, -1.0)).rgb;\n"
    "  s += texture(uSrc, vUV + uTexel * vec2( 1.0, -1.0)).rgb;\n"
    "  s += texture(uSrc, vUV + uTexel * vec2(-1.0,  1.0)).rgb;\n"
    "  s += texture(uSrc, vUV + uTexel * vec2( 1.0,  1.0)).rgb;\n"
    "  oC = vec4(s * 0.125, 1.0);\n"
    "}\n";

static const char* kFS_Up =
    "in vec2 vUV; out vec4 oC;\n"
    "uniform sampler2D uSrc;\n"
    "uniform vec2 uTexel;  // 1 / source size\n"
    "uniform float uW;\n"
    "void main(){\n"
    "  vec2 h = uTexel * 0.5;\n"
    "  vec3 s = texture(uSrc, vUV + vec2(-h.x * 2.0, 0.0)).rgb;\n"
    "  s += texture(uSrc, vUV + vec2(-h.x,  h.y)).rgb * 2.0;\n"
    "  s += texture(uSrc, vUV + vec2(0.0,  h.y * 2.0)).rgb;\n"
    "  s += texture(uSrc, vUV + vec2( h.x,  h.y)).rgb * 2.0;\n"
    "  s += texture(uSrc, vUV + vec2( h.x * 2.0, 0.0)).rgb;\n"
    "  s += texture(uSrc, vUV + vec2( h.x, -h.y)).rgb * 2.0;\n"
    "  s += texture(uSrc, vUV + vec2(0.0, -h.y * 2.0)).rgb;\n"
    "  s += texture(uSrc, vUV + vec2(-h.x, -h.y)).rgb * 2.0;\n"
    "  oC = vec4(s / 12.0 * uW, 1.0);\n"
    "}\n";

static const char* kFS_Composite =
    "in vec2 vUV; out vec4 oC;\n"
    "uniform sampler2D uScene;\n"
    "uniform sampler2D uAOTex;\n"
    "uniform sampler2D uBloomTex;\n"
    "uniform vec4  uFlags;   // ao on, bloom on, aoStrength, bloomIntensity\n"
    "uniform vec4  uGrade;   // exposure, tonemapMix, contrast, saturation\n"
    "uniform vec4  uTint;    // rgb tint, vignette\n"
    "uniform vec4  uX;       // ssr on, wetness, fog on, fog density\n"
    "uniform vec4  uSSR;     // strength, steps, maxDist, thickness\n"
    "uniform vec4  uFogCol;  // rgb, fog strength\n"
    "uniform vec2  uPx;      // 1 / full-res size\n"
    "uniform float uDbg;     // 0 normal, 1 depth, 2 ao\n"
    "uniform float uClarity; // local contrast (HD look)\n"
    "uniform float uLift;    // shadow lift: brightens dark areas (buildings in shade) more than bright ones\n"
    "uniform vec4  uSplitS;  // shadow tint rgb, amount\n"
    "uniform vec4  uSplitH;  // highlight tint rgb, amount\n"
    "vec3 aces(vec3 x){ return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0); }\n"
    "vec3 viewNormal(vec2 uv, vec3 p){\n"
    "  vec3 pr = viewPos(uv + vec2(uPx.x, 0.0)), pl = viewPos(uv - vec2(uPx.x, 0.0));\n"
    "  vec3 pu = viewPos(uv + vec2(0.0, uPx.y)), pd = viewPos(uv - vec2(0.0, uPx.y));\n"
    "  vec3 dx = abs(pr.z - p.z) < abs(pl.z - p.z) ? pr - p : p - pl;\n"
    "  vec3 dy = abs(pu.z - p.z) < abs(pd.z - p.z) ? pu - p : p - pd;\n"
    "  return -normalize(cross(dx, dy));\n"
    "}\n"
    "// returns rgb (gamma space scene colour) in .rgb and hit weight in .a\n"
    "vec4 traceSSR(vec2 uv, vec3 p, vec3 n){\n"
    "  vec3 v = normalize(p);\n"
    "  vec3 r = reflect(v, n);\n"
    "  if (r.z < 0.02) return vec4(0.0);\n"
    "  float steps = uSSR.y;\n"
    "  float stepLen = uSSR.z / steps;\n"
    "  float j = ign(gl_FragCoord.xy);\n"
    "  for (int i = 0; i < 32; i++) {\n"
    "    if (float(i) >= steps) break;\n"
    "    vec3 q = p + r * stepLen * (float(i) + 0.5 + j);\n"
    "    if (q.z <= 0.05) break;\n"
    "    vec2 suv = (q.xy / (q.z * uProj.xy)) * 0.5 + 0.5;\n"
    "    if (suv.x < 0.0 || suv.x > 1.0 || suv.y < 0.0 || suv.y > 1.0) break;\n"
    "    float sz = linZ(texture(uDepth, suv).r);\n"
    "    float diff = q.z - sz;\n"
    "    if (diff > 0.0 && diff < uSSR.w * (1.0 + q.z * 0.05)) {\n"
    "      vec2 e = min(suv, 1.0 - suv) * 6.0;\n"
    "      float edge = clamp(min(e.x, e.y), 0.0, 1.0);\n"
    "      float dist = 1.0 - float(i) / steps;\n"
    "      return vec4(texture(uScene, suv).rgb, edge * dist);\n"
    "    }\n"
    "  }\n"
    "  return vec4(0.0);\n"
    "}\n"
    "void main(){\n"
    "  vec3 c = texture(uScene, vUV).rgb;\n"
    "  if (uClarity > 0.0) {\n"
    "    vec3 bl = mix(textureLod(uScene, vUV, 2.0).rgb, textureLod(uScene, vUV, 4.0).rgb, 0.5);\n"
    "    c = clamp(c + clamp(c - bl, -0.25, 0.25) * uClarity, 0.0, 1.0);\n"
    "  }\n"
    "  vec3 lin = pow(c, vec3(2.2));\n"
    "  float d = texture(uDepth, vUV).r;\n"
    "  bool isSky = d >= 0.99999;\n"
    "  if (uDbg > 0.5 && uDbg < 1.5) { float z = linZ(d); oC = vec4(vec3(isSky ? 1.0 : fract(z * 0.05)), 1.0); return; }\n"
    "  if (uDbg > 1.5) { oC = vec4(vec3(texture(uAOTex, vUV).r), 1.0); return; }\n"
    "  if (uFlags.x > 0.5) {\n"
    "    float ao = texture(uAOTex, vUV).r;\n"
    "    lin *= mix(1.0, ao, uFlags.z);\n"
    "  }\n"
    "  if (uX.x > 0.5 && !isSky) {\n"
    "    vec3 p = viewPos(vUV);\n"
    "    if (p.z < uSSR.z * 2.0) {\n"
    "      vec3 n = viewNormal(vUV, p);\n"
    "      float up = smoothstep(0.55, 0.9, n.y);\n"
    "      if (up > 0.0) {\n"
    "        vec4 h = traceSSR(vUV, p, n);\n"
    "        float fres = 0.08 + 0.92 * pow(1.0 - clamp(dot(-normalize(p), n), 0.0, 1.0), 4.0);\n"
    "        float k = uSSR.x * uX.y * up * fres * h.a;\n"
    "        lin = mix(lin, pow(h.rgb, vec3(2.2)), clamp(k, 0.0, 0.85));\n"
    "      }\n"
    "    }\n"
    "  }\n"
    "  if (uX.z > 0.5 && !isSky) {\n"
    "    float z = linZ(d);\n"
    "    float f = 1.0 - exp(-z * uX.w);\n"
    "    lin = mix(lin, uFogCol.rgb, clamp(f * uFogCol.a, 0.0, 1.0));\n"
    "  }\n"
    "  if (uFlags.y > 0.5) {\n"
    "    lin += pow(texture(uBloomTex, vUV).rgb, vec3(2.2)) * uFlags.w;\n"
    "  }\n"
    "  lin *= uGrade.x * uTint.rgb;\n"
    "  lin = mix(lin, aces(lin), uGrade.y);\n"
    "  vec3 o = pow(max(lin, vec3(0.0)), vec3(1.0 / 2.2));\n"
    "  o = (o - 0.5) * uGrade.z + 0.5;\n"
    "  o = pow(max(o, vec3(0.0)), vec3(1.0 / (1.0 + uLift)));\n"
    "  float l = dot(o, vec3(0.299, 0.587, 0.114));\n"
    "  float sat = max(o.r, max(o.g, o.b)) - min(o.r, min(o.g, o.b));\n"
    "  o = mix(vec3(l), o, mix(uGrade.w, 1.0, clamp(sat * 1.6, 0.0, 1.0)));   // vibrance: keep sky/paint colour, mute ground\n"
    "  float l2 = dot(o, vec3(0.299, 0.587, 0.114));\n"
    "  o *= mix(vec3(1.0), uSplitS.rgb, (1.0 - smoothstep(0.0, 0.55, l2)) * uSplitS.a);\n"
    "  o *= mix(vec3(1.0), uSplitH.rgb, smoothstep(0.45, 1.0, l2) * uSplitH.a);\n"
    "  vec2 q = vUV - 0.5;\n"
    "  o *= 1.0 - dot(q, q) * uTint.w * 2.2;\n"
    "  o += (ign(gl_FragCoord.xy) - 0.5) / 255.0;\n"
    "  oC = vec4(clamp(o, 0.0, 1.0), 1.0);\n"
    "}\n";

static const char* kFS_FXAA =
    "in vec2 vUV; out vec4 oC;\n"
    "uniform sampler2D uSrc;\n"
    "uniform vec2 uTexel;\n"
    "uniform vec2 uOpt;   // fxaa on, sharpen\n"
    "uniform float uSmooth; // edge-preserving smoothing of texture detail\n"
    "float luma(vec3 c){ return dot(c, vec3(0.299, 0.587, 0.114)); }\n"
    "void main(){\n"
    "  vec3 M  = texture(uSrc, vUV).rgb;\n"
    "  vec3 NW = texture(uSrc, vUV + uTexel * vec2(-1.0, -1.0)).rgb;\n"
    "  vec3 NE = texture(uSrc, vUV + uTexel * vec2( 1.0, -1.0)).rgb;\n"
    "  vec3 SW = texture(uSrc, vUV + uTexel * vec2(-1.0,  1.0)).rgb;\n"
    "  vec3 SE = texture(uSrc, vUV + uTexel * vec2( 1.0,  1.0)).rgb;\n"
    "  float lM = luma(M), lNW = luma(NW), lNE = luma(NE), lSW = luma(SW), lSE = luma(SE);\n"
    "  float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));\n"
    "  float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));\n"
    "  vec3 res = M;\n"
    "  if (uOpt.x > 0.5 && (lMax - lMin) > max(0.0312, lMax * 0.125)) {\n"
    "    vec2 dir = vec2(-((lNW + lNE) - (lSW + lSE)), (lNW + lSW) - (lNE + lSE));\n"
    "    float red = max((lNW + lNE + lSW + lSE) * 0.03125, 0.0078125);\n"
    "    float rcp = 1.0 / (min(abs(dir.x), abs(dir.y)) + red);\n"
    "    dir = clamp(dir * rcp, -8.0, 8.0) * uTexel;\n"
    "    vec3 A = 0.5 * (texture(uSrc, vUV + dir * (1.0 / 3.0 - 0.5)).rgb + texture(uSrc, vUV + dir * (2.0 / 3.0 - 0.5)).rgb);\n"
    "    vec3 B = A * 0.5 + 0.25 * (texture(uSrc, vUV + dir * -0.5).rgb + texture(uSrc, vUV + dir * 0.5).rgb);\n"
    "    float lB = luma(B);\n"
    "    res = (lB < lMin || lB > lMax) ? A : B;\n"
    "  } else if (uOpt.y > 0.0) {\n"
    "    vec3 avg = (NW + NE + SW + SE) * 0.25;\n"
    "    res = M + clamp(M - avg, -0.1, 0.1) * uOpt.y * 2.0;\n"
    "  }\n"
    "  if (uSmooth > 0.0) {\n"
    "    vec2 offs[8] = vec2[8](vec2(-1.0,-1.0), vec2(0.0,-1.0), vec2(1.0,-1.0), vec2(-1.0,0.0), vec2(1.0,0.0), vec2(-1.0,1.0), vec2(0.0,1.0), vec2(1.0,1.0));\n"
    "    vec3 acc = res; float ws = 1.0;\n"
    "    for (int i = 0; i < 8; i++) {\n"
    "      vec3 c = texture(uSrc, vUV + uTexel * offs[i] * 1.5).rgb;\n"
    "      vec3 d = c - res;\n"
    "      float w = exp(-dot(d, d) * 40.0);\n"
    "      acc += c * w; ws += w;\n"
    "    }\n"
    "    res = mix(res, acc / ws, uSmooth);\n"
    "  }\n"
    "  oC = vec4(clamp(res, 0.0, 1.0), 1.0);\n"
    "}\n";

// ------------------------------------------------------------------------------------------------
// GL helpers
// ------------------------------------------------------------------------------------------------
void GLStateGuard::Save()
{
    glGetIntegerv(GL_CURRENT_PROGRAM, &program);
    glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING, &drawFbo);
    glGetIntegerv(GL_READ_FRAMEBUFFER_BINDING, &readFbo);
    glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &vao);
    glGetIntegerv(GL_VIEWPORT, viewport);
    glGetIntegerv(GL_SCISSOR_BOX, scissor);
    glGetIntegerv(GL_ACTIVE_TEXTURE, &activeTex);
    for (int i = 0; i < 4; i++)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glGetIntegerv(GL_TEXTURE_BINDING_2D, &tex2D[i]);
    }
    glActiveTexture(activeTex);
    blend = glIsEnabled(GL_BLEND);
    depthTest = glIsEnabled(GL_DEPTH_TEST);
    cull = glIsEnabled(GL_CULL_FACE);
    scissorTest = glIsEnabled(GL_SCISSOR_TEST);
    stencilTest = glIsEnabled(GL_STENCIL_TEST);
    dither = glIsEnabled(GL_DITHER);
    glGetBooleanv(GL_COLOR_WRITEMASK, colorMask);
    glGetBooleanv(GL_DEPTH_WRITEMASK, &depthMask);
    glGetIntegerv(GL_BLEND_SRC_RGB, &blendSrcRGB);
    glGetIntegerv(GL_BLEND_DST_RGB, &blendDstRGB);
    glGetIntegerv(GL_BLEND_SRC_ALPHA, &blendSrcA);
    glGetIntegerv(GL_BLEND_DST_ALPHA, &blendDstA);
    glGetIntegerv(GL_BLEND_EQUATION_RGB, &blendEqRGB);
    glGetIntegerv(GL_BLEND_EQUATION_ALPHA, &blendEqA);
}

void GLStateGuard::Restore()
{
    for (int i = 0; i < 4; i++)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, tex2D[i]);
    }
    glActiveTexture(activeTex);
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER, drawFbo);
    glBindFramebuffer(GL_READ_FRAMEBUFFER, readFbo);
    glBindVertexArray(vao);
    glUseProgram(program);
    glViewport(viewport[0], viewport[1], viewport[2], viewport[3]);
    glScissor(scissor[0], scissor[1], scissor[2], scissor[3]);
    glBlendFuncSeparate(blendSrcRGB, blendDstRGB, blendSrcA, blendDstA);
    glBlendEquationSeparate(blendEqRGB, blendEqA);
    glColorMask(colorMask[0], colorMask[1], colorMask[2], colorMask[3]);
    glDepthMask(depthMask);
    (blend ? glEnable : glDisable)(GL_BLEND);
    (depthTest ? glEnable : glDisable)(GL_DEPTH_TEST);
    (cull ? glEnable : glDisable)(GL_CULL_FACE);
    (scissorTest ? glEnable : glDisable)(GL_SCISSOR_TEST);
    (stencilTest ? glEnable : glDisable)(GL_STENCIL_TEST);
    (dither ? glEnable : glDisable)(GL_DITHER);
}

static GLuint CompileStage(GLenum type, const char* src1, const char* src2, const char* src3, const char* name)
{
    GLuint sh = glCreateShader(type);
    const char* srcs[3] = { src1, src2, src3 };
    glShaderSource(sh, 3, srcs, NULL);
    glCompileShader(sh);
    GLint ok = 0;
    glGetShaderiv(sh, GL_COMPILE_STATUS, &ok);
    if (!ok)
    {
        char log[1024] = {0};
        glGetShaderInfoLog(sh, sizeof(log) - 1, NULL, log);
        RGO_LOGE("Shader '%s' failed: %s", name, log);
        glDeleteShader(sh);
        return 0;
    }
    return sh;
}

// fragment source = kHead + (optional lib) + body
static GLuint MakeProgram(const char* name, const char* lib, const char* fsBody)
{
    GLuint vs = CompileStage(GL_VERTEX_SHADER, kHead, "", kVS, name);
    // fragment: head + lib + body
    GLuint fs = CompileStage(GL_FRAGMENT_SHADER, kHead, lib ? lib : "", fsBody, name);
    if (!vs || !fs) { if (vs) glDeleteShader(vs); if (fs) glDeleteShader(fs); return 0; }
    GLuint p = glCreateProgram();
    glAttachShader(p, vs);
    glAttachShader(p, fs);
    glLinkProgram(p);
    glDeleteShader(vs);
    glDeleteShader(fs);
    GLint ok = 0;
    glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok)
    {
        char log[1024] = {0};
        glGetProgramInfoLog(p, sizeof(log) - 1, NULL, log);
        RGO_LOGE("Program '%s' link failed: %s", name, log);
        glDeleteProgram(p);
        return 0;
    }
    return p;
}

static void CreateRT(RGORT& rt, int w, int h, GLenum internalFmt, GLenum filter = GL_LINEAR)
{
    rt.w = w; rt.h = h;
    glGenTextures(1, &rt.tex);
    glBindTexture(GL_TEXTURE_2D, rt.tex);
    glTexStorage2D(GL_TEXTURE_2D, 1, internalFmt, w, h);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filter);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filter);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glGenFramebuffers(1, &rt.fbo);
    glBindFramebuffer(GL_FRAMEBUFFER, rt.fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, rt.tex, 0);
}

static void DestroyRT(RGORT& rt)
{
    if (rt.fbo) glDeleteFramebuffers(1, &rt.fbo);
    if (rt.tex) glDeleteTextures(1, &rt.tex);
    rt = RGORT();
}

// ------------------------------------------------------------------------------------------------
// Pipeline state
// ------------------------------------------------------------------------------------------------
static const int MAX_BLOOM = 6;

static struct
{
    bool  inited = false, failed = false, depthOK = true;
    int   w = 0, h = 0;
    GLuint vao = 0;
    GLuint pSSAO = 0, pBlur = 0, pPre = 0, pDown = 0, pUp = 0, pComp = 0, pFXAA = 0;
    GLuint sceneTex = 0, depthTex = 0, depthFbo = 0;
    GLenum depthFmt = GL_DEPTH_COMPONENT24;
    bool  depthStencil = false;
    int   dW = 0, dH = 0;
    int   lastSrcFbo = -2;
    RGORT aoA, aoB, comp;
    RGORT bloom[MAX_BLOOM];
    int   bloomN = 0;
    bool  loggedFirst = false, loggedRun = false;
} S;

static inline void Tex(int unit, GLuint tex)
{
    glActiveTexture(GL_TEXTURE0 + unit);
    glBindTexture(GL_TEXTURE_2D, tex);
}
static inline void Target(const RGORT& rt)
{
    glBindFramebuffer(GL_FRAMEBUFFER, rt.fbo);
    glViewport(0, 0, rt.w, rt.h);
}
static inline GLint Loc(GLuint p, const char* n) { return glGetUniformLocation(p, n); }
static inline void Use(GLuint p) { glUseProgram(p); }
static inline void Draw() { glDrawArrays(GL_TRIANGLES, 0, 3); }

// (Re)creates the depth copy texture with the given format. glBlitFramebuffer needs matching formats.
static void MakeDepthTex(int w, int h)
{
    if (S.depthTex) { glDeleteTextures(1, &S.depthTex); S.depthTex = 0; }
    if (S.depthFbo) { glDeleteFramebuffers(1, &S.depthFbo); S.depthFbo = 0; }
    glGenTextures(1, &S.depthTex);
    glBindTexture(GL_TEXTURE_2D, S.depthTex);
    glTexStorage2D(GL_TEXTURE_2D, 1, S.depthFmt, w, h);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glGenFramebuffers(1, &S.depthFbo);
    glBindFramebuffer(GL_FRAMEBUFFER, S.depthFbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, S.depthStencil ? GL_DEPTH_STENCIL_ATTACHMENT : GL_DEPTH_ATTACHMENT,
                           GL_TEXTURE_2D, S.depthTex, 0);
    GLenum st = glCheckFramebufferStatus(GL_FRAMEBUFFER);
    if (st != GL_FRAMEBUFFER_COMPLETE) { RGO_LOGE("Depth FBO incomplete (0x%X), SSAO disabled", st); S.depthOK = false; }
    S.dW = w; S.dH = h;
}

struct DepthInfo { bool valid = false; GLenum fmt = 0; bool stencil = false; int w = 0, h = 0; GLint type = 0, name = 0; };

// Looks at the depth attachment of an FBO (0 = default framebuffer) and works out its format and size.
static DepthInfo QueryDepth(GLint fbo, int fallbackW, int fallbackH)
{
    DepthInfo di;
    glBindFramebuffer(GL_READ_FRAMEBUFFER, fbo);
    GLint db = 0, sb = 0, ctype = 0;
    if (fbo == 0)
    {
        glGetIntegerv(GL_DEPTH_BITS, &db);
        glGetIntegerv(GL_STENCIL_BITS, &sb);
        di.w = fallbackW; di.h = fallbackH;
    }
    else
    {
        glGetFramebufferAttachmentParameteriv(GL_READ_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE, &di.type);
        if (di.type == GL_NONE) { while (glGetError() != GL_NO_ERROR) {} return di; }
        glGetFramebufferAttachmentParameteriv(GL_READ_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME, &di.name);
        glGetFramebufferAttachmentParameteriv(GL_READ_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE, &db);
        glGetFramebufferAttachmentParameteriv(GL_READ_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_FRAMEBUFFER_ATTACHMENT_STENCIL_SIZE, &sb);
        glGetFramebufferAttachmentParameteriv(GL_READ_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE, &ctype);
        di.w = fallbackW; di.h = fallbackH;
        if (di.type == GL_TEXTURE)
        {
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, (GLuint)di.name);
            GLint tw = 0, th = 0;
            glGetTexLevelParameteriv(GL_TEXTURE_2D, 0, GL_TEXTURE_WIDTH, &tw);
            glGetTexLevelParameteriv(GL_TEXTURE_2D, 0, GL_TEXTURE_HEIGHT, &th);
            if (tw > 0 && th > 0) { di.w = tw; di.h = th; }
        }
        else if (di.type == GL_RENDERBUFFER)
        {
            GLint prevRb = 0, rw = 0, rh = 0;
            glGetIntegerv(GL_RENDERBUFFER_BINDING, &prevRb);
            glBindRenderbuffer(GL_RENDERBUFFER, (GLuint)di.name);
            glGetRenderbufferParameteriv(GL_RENDERBUFFER, GL_RENDERBUFFER_WIDTH, &rw);
            glGetRenderbufferParameteriv(GL_RENDERBUFFER, GL_RENDERBUFFER_HEIGHT, &rh);
            glBindRenderbuffer(GL_RENDERBUFFER, (GLuint)prevRb);
            if (rw > 0 && rh > 0) { di.w = rw; di.h = rh; }
        }
    }
    di.stencil = sb > 0;
    if (db >= 32 && ctype == GL_FLOAT)   { di.fmt = sb ? GL_DEPTH32F_STENCIL8 : GL_DEPTH_COMPONENT32F; di.valid = true; }
    else if (db >= 24)                   { di.fmt = sb ? GL_DEPTH24_STENCIL8 : GL_DEPTH_COMPONENT24; di.valid = true; }
    else if (db >= 16)                   { di.fmt = GL_DEPTH_COMPONENT16; di.valid = true; }
    while (glGetError() != GL_NO_ERROR) {}
    return di;
}

static void ReleaseTargets()
{
    DestroyRT(S.aoA); DestroyRT(S.aoB); DestroyRT(S.comp);
    for (int i = 0; i < MAX_BLOOM; i++) DestroyRT(S.bloom[i]);
    if (S.sceneTex) { glDeleteTextures(1, &S.sceneTex); S.sceneTex = 0; }
    if (S.depthTex) { glDeleteTextures(1, &S.depthTex); S.depthTex = 0; }
    if (S.depthFbo) { glDeleteFramebuffers(1, &S.depthFbo); S.depthFbo = 0; }
}

static void CreateTargets(int w, int h)
{
    ReleaseTargets();
    S.w = w; S.h = h;

    // scene copy: RGB8 is a component-subset of any default framebuffer format, so copy is always legal
    glGenTextures(1, &S.sceneTex);
    glBindTexture(GL_TEXTURE_2D, S.sceneTex);
    {
        int lv = 1, m = (w > h ? w : h);
        while (m > 1) { m >>= 1; lv++; }
        glTexStorage2D(GL_TEXTURE_2D, lv, GL_RGB8, w, h);   // full mip chain: used for the blurred copy (clarity)
    }
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    MakeDepthTex(w, h);

    CreateRT(S.aoA, w / 2, h / 2, GL_R8);
    CreateRT(S.aoB, w / 2, h / 2, GL_R8);
    CreateRT(S.comp, w, h, GL_RGBA8);

    S.bloomN = g_RGO.bloomLevels < 2 ? 2 : (g_RGO.bloomLevels > MAX_BLOOM ? MAX_BLOOM : g_RGO.bloomLevels);
    int bw = w / 2, bh = h / 2;
    for (int i = 0; i < S.bloomN; i++)
    {
        if (bw < 2) bw = 2;
        if (bh < 2) bh = 2;
        CreateRT(S.bloom[i], bw, bh, GL_RGBA8);
        bw /= 2; bh /= 2;
    }
    RGO_LOGI("RGO targets created %dx%d (bloom levels: %d)", w, h, S.bloomN);
}

static bool InitPipeline()
{
    const char* ver = (const char*)glGetString(GL_VERSION);
    int major = 0, minor = 0;
    if (!ver || sscanf(ver, "OpenGL ES %d.%d", &major, &minor) < 1 || major < 3)
    {
        RGO_LOGE("RGO needs OpenGL ES 3.0+, got '%s'. Disabled.", ver ? ver : "?");
        return false;
    }
    RGO_LOGI("GL: %s | %s", ver, (const char*)glGetString(GL_RENDERER));

    GLint depthBits = 0, stencilBits = 0;
    glGetIntegerv(GL_DEPTH_BITS, &depthBits);
    glGetIntegerv(GL_STENCIL_BITS, &stencilBits);
    S.depthStencil = false;
    if (depthBits >= 32)                       S.depthFmt = GL_DEPTH_COMPONENT32F;
    else if (depthBits >= 24 && stencilBits)   { S.depthFmt = GL_DEPTH24_STENCIL8; S.depthStencil = true; }
    else if (depthBits >= 24)                  S.depthFmt = GL_DEPTH_COMPONENT24;
    else if (depthBits >= 16)                  S.depthFmt = GL_DEPTH_COMPONENT16;
    else { RGO_LOGI("Default framebuffer has no depth (%d bits). SSAO disabled.", depthBits); S.depthOK = false; }
    RGO_LOGI("Default FB depth=%d stencil=%d", depthBits, stencilBits);

    S.pSSAO  = MakeProgram("ssao",      kDepthLib, kFS_SSAO);
    S.pBlur  = MakeProgram("ssaoblur",  kDepthLib, kFS_Blur);
    S.pPre   = MakeProgram("prefilter", NULL,      kFS_Prefilter);
    S.pDown  = MakeProgram("down",      NULL,      kFS_Down);
    S.pUp    = MakeProgram("up",        NULL,      kFS_Up);
    S.pComp  = MakeProgram("composite", kDepthLib, kFS_Composite);
    S.pFXAA  = MakeProgram("fxaa",      NULL,      kFS_FXAA);
    if (!S.pSSAO || !S.pBlur || !S.pPre || !S.pDown || !S.pUp || !S.pComp || !S.pFXAA) return false;

    glGenVertexArrays(1, &S.vao);
    return true;
}

// ------------------------------------------------------------------------------------------------
// Time of day grading
// ------------------------------------------------------------------------------------------------
struct TodKey { float h, r, g, b, exp, fr, fg, fb; };
static const TodKey kTod[] = {
    {  0.0f, 0.80f, 0.90f, 1.15f, 1.20f, 0.03f, 0.05f, 0.09f },
    {  4.5f, 0.85f, 0.92f, 1.12f, 1.15f, 0.05f, 0.07f, 0.12f },
    {  6.0f, 1.10f, 0.97f, 0.86f, 1.05f, 0.55f, 0.42f, 0.38f },
    {  8.0f, 1.05f, 1.00f, 0.92f, 1.00f, 0.55f, 0.65f, 0.80f },
    { 12.0f, 1.04f, 1.00f, 0.93f, 0.98f, 0.68f, 0.74f, 0.82f },
    { 17.0f, 1.06f, 1.00f, 0.90f, 1.00f, 0.66f, 0.68f, 0.76f },
    { 19.0f, 1.12f, 0.96f, 0.82f, 1.05f, 0.72f, 0.45f, 0.32f },
    { 21.0f, 0.88f, 0.93f, 1.10f, 1.15f, 0.06f, 0.08f, 0.14f },
    { 24.0f, 0.80f, 0.90f, 1.15f, 1.20f, 0.03f, 0.05f, 0.09f },
};

// out: [0..2] tint, [3] exposure, [4..6] fog colour
static void TimeOfDay(float out[8])
{
    for (int i = 0; i < 8; i++) out[i] = 1.0f;
    out[4] = 0.6f; out[5] = 0.7f; out[6] = 0.85f;
    if (!g_RGO.timeOfDayGrade) return;
    float hr = (float)CClock::ms_nGameClockHours + (float)CClock::ms_nGameClockMinutes / 60.0f;
    const int n = sizeof(kTod) / sizeof(kTod[0]);
    for (int i = 0; i < n - 1; i++)
    {
        if (hr >= kTod[i].h && hr <= kTod[i + 1].h)
        {
            const TodKey& a = kTod[i]; const TodKey& b = kTod[i + 1];
            float t = (hr - a.h) / (b.h - a.h);
            out[0] = a.r + (b.r - a.r) * t;   out[1] = a.g + (b.g - a.g) * t;   out[2] = a.b + (b.b - a.b) * t;
            out[3] = a.exp + (b.exp - a.exp) * t;
            out[4] = a.fr + (b.fr - a.fr) * t; out[5] = a.fg + (b.fg - a.fg) * t; out[6] = a.fb + (b.fb - a.fb) * t;
            return;
        }
    }
}

// ------------------------------------------------------------------------------------------------
// Frame
// ------------------------------------------------------------------------------------------------
// Debug marker: proves that the hook runs even if the effects are invisible.
static void Marker(float r, float g, float b)
{
    if (!g_RGO.debugMarker) return;
    GLint fbo = 0, sc[4]; GLfloat cc[4];
    GLboolean sct = glIsEnabled(GL_SCISSOR_TEST);
    GLboolean cm[4];
    glGetIntegerv(GL_FRAMEBUFFER_BINDING, &fbo);
    glGetIntegerv(GL_SCISSOR_BOX, sc);
    glGetFloatv(GL_COLOR_CLEAR_VALUE, cc);
    glGetBooleanv(GL_COLOR_WRITEMASK, cm);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
    glEnable(GL_SCISSOR_TEST);
    glScissor(8, 8, 64, 64);
    glClearColor(r, g, b, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    glScissor(sc[0], sc[1], sc[2], sc[3]);
    if (!sct) glDisable(GL_SCISSOR_TEST);
    glClearColor(cc[0], cc[1], cc[2], cc[3]);
    glColorMask(cm[0], cm[1], cm[2], cm[3]);
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);
}

void RGO_OnSwapBuffers(void* eglDisplay, void* eglSurface)
{
    static int s_calls = 0;
    if (s_calls < 3) { s_calls++; RGO_LOGI("eglSwapBuffers hook reached (#%d)", s_calls); }
    RGO_FlushPendingTex();   // never leave a texture half-uploaded across frames
    if (!g_RGO.enabled || S.failed) return;
    {
        // Everything switched off / neutral: do no GL work at all (zero cost, picture is untouched).
        const RGOSettings& g = g_RGO;
        const bool neutral = !g.ssao && !g.ssr && !g.fog && !g.bloom && !g.fxaa && g.sharpen <= 0.0f && g.clarity <= 0.0f &&
                             g.textureSmooth <= 0.0f && g.exposure == 1.0f && g.tonemapMix <= 0.0f && g.contrast == 1.0f &&
                             g.saturation == 1.0f && g.vignette <= 0.0f && g.splitTone <= 0.0f && g.shadowLift <= 0.0f &&
                             !g.timeOfDayGrade && g.debugView == 0 && !g.debugMarker;
        if (neutral) return;
    }
    if (eglGetCurrentContext() == EGL_NO_CONTEXT) { if (s_calls < 3) RGO_LOGI("no current EGL context"); return; }

    Marker(0.0f, 0.2f, 1.0f);

    EGLint sw = 0, sh = 0;
    eglQuerySurface((EGLDisplay)eglDisplay, (EGLSurface)eglSurface, EGL_WIDTH, &sw);
    eglQuerySurface((EGLDisplay)eglDisplay, (EGLSurface)eglSurface, EGL_HEIGHT, &sh);
    if (sw < 64 || sh < 64) { if (s_calls < 3) RGO_LOGI("surface too small %dx%d", sw, sh); return; }

    // version check first: on an ES2 context the ES3 queries below would just raise GL errors
    if (!S.inited)
    {
        const char* ver = (const char*)glGetString(GL_VERSION);
        RGO_LOGI("GL_VERSION = %s, surface %dx%d", ver ? ver : "null", sw, sh);
    }

    // Whatever FBO the game left bound, the image that gets presented lives in the default framebuffer,
    // so we always process FB 0 (GLStateGuard restores the game's binding afterwards).
    {
        static int s_log = 0;
        GLint curFbo = -1;
        glGetIntegerv(GL_FRAMEBUFFER_BINDING, &curFbo);
        if (curFbo != 0 && s_log < 3) { s_log++; RGO_LOGI("note: FBO %d bound at swap, processing FB 0 anyway", curFbo); }
    }

    while (glGetError() != GL_NO_ERROR) {} // don't blame ourselves for the game's leftovers

    GLStateGuard guard;
    guard.Save();

    if (!S.inited)
    {
        S.inited = true;
        if (!InitPipeline()) { S.failed = true; guard.Restore(); return; }
    }
    if (S.w != sw || S.h != sh)
    {
        CreateTargets(sw, sh);
    }

    const bool useAO    = (g_RGO.ssao || g_RGO.ssr || g_RGO.fog);
    const bool useBloom = g_RGO.bloom;

    // --- 1. copy color (+ depth) from the default framebuffer
    const GLint dstFbo = (g_RGO.targetMode == 1) ? guard.drawFbo : 0;
    glBindFramebuffer(GL_READ_FRAMEBUFFER, dstFbo);
    Tex(0, S.sceneTex);
    glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, sw, sh);
    glGenerateMipmap(GL_TEXTURE_2D);

    if (useAO)
    {
        // Pick where the real scene depth lives. In-game the scene is drawn into an off-screen FBO, so the
        // default framebuffer's depth is empty (all 1.0); the FBO left bound at swap time usually holds it.
        GLint depthSrc = 0;
        DepthInfo di = QueryDepth(0, sw, sh);
        if (g_RGO.depthSource != 1 && guard.drawFbo != 0)
        {
            DepthInfo db = QueryDepth(guard.drawFbo, sw, sh);
            const bool big = db.w * 2 >= sw && db.h * 2 >= sh;   // ignore small targets such as shadow maps
            if (db.valid && (big || g_RGO.depthSource == 2)) { di = db; depthSrc = guard.drawFbo; }
            if (S.lastSrcFbo != depthSrc || !S.loggedRun)
                RGO_LOGI("depth source: FBO %d type=0x%X fmt=0x%X stencil=%d %dx%d valid=%d big=%d (bound FBO %d)",
                         depthSrc, db.type, db.fmt, (int)db.stencil, db.w, db.h, (int)db.valid, (int)big, guard.drawFbo);
        }
        if (S.lastSrcFbo != depthSrc) S.depthOK = true;   // new source: give it a fresh chance
        S.lastSrcFbo = depthSrc;

        if (di.valid && (di.fmt != S.depthFmt || di.stencil != S.depthStencil || S.dW != sw || S.dH != sh))
        {
            S.depthFmt = di.fmt; S.depthStencil = di.stencil;
            S.depthOK = true;
            MakeDepthTex(sw, sh);
            RGO_LOGI("depth texture recreated: fmt=0x%X stencil=%d", di.fmt, (int)di.stencil);
        }
        if (di.valid && S.depthOK)
        {
            while (glGetError() != GL_NO_ERROR) {}
            glBindFramebuffer(GL_READ_FRAMEBUFFER, depthSrc);
            glBindFramebuffer(GL_DRAW_FRAMEBUFFER, S.depthFbo);
            glBlitFramebuffer(0, 0, di.w, di.h, 0, 0, sw, sh, GL_DEPTH_BUFFER_BIT, GL_NEAREST);
            GLenum be = glGetError();
            if (be != GL_NO_ERROR)
            {
                static int s_errs = 0;
                if (s_errs++ < 5) RGO_LOGE("Depth blit from FBO %d failed (0x%X). SSAO/SSR/fog off for this frame.", depthSrc, be);
                S.depthOK = false;
            }
        }
        else if (!di.valid) S.depthOK = false;
    }
    const bool aoNow = g_RGO.ssao && S.depthOK;

    // --- 2. common state
    glBindVertexArray(S.vao);
    glDisable(GL_BLEND); glDisable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE);
    glDisable(GL_SCISSOR_TEST); glDisable(GL_STENCIL_TEST); glDisable(GL_DITHER);
    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
    glDepthMask(GL_FALSE);

    // camera parameters straight from the game
    float fov    = CDraw::ms_fFOV;                   // vertical or horizontal depends on build, see README
    float nearZ  = CDraw::ms_fNearClipZ;
    float farZ   = CDraw::ms_fFarClipZ;
    float aspect = (float)sw / (float)sh;
    if (nearZ < 0.01f) nearZ = 0.1f;
    if (farZ <= nearZ + 1.0f) farZ = 300.0f;
    // GTA's FOV is the horizontal angle of a 4:3 view window; vertical extent stays fixed in widescreen
    float tanX0 = tanf(fov * 0.5f * 3.14159265f / 180.0f);
    float tanY  = tanX0 * 0.75f;
    float tanX  = tanY * aspect;

    // --- 3. SSAO
    if (aoNow)
    {
        Use(S.pSSAO);
        Tex(1, S.depthTex);
        glUniform1i(Loc(S.pSSAO, "uDepth"), 1);
        glUniform4f(Loc(S.pSSAO, "uProj"), tanX, tanY, nearZ, farZ);
        glUniform1f(Loc(S.pSSAO, "uMode"), (float)g_RGO.depthMode);
        glUniform2f(Loc(S.pSSAO, "uPx"), 1.0f / sw, 1.0f / sh);
        glUniform4f(Loc(S.pSSAO, "uAO"), g_RGO.ssaoRadius, g_RGO.ssaoIntensity, g_RGO.ssaoBias, 0.0f);
        glUniform2f(Loc(S.pSSAO, "uFade"), g_RGO.ssaoFadeStart, g_RGO.ssaoFadeEnd);
        Target(S.aoA);
        Draw();

        Use(S.pBlur);
        glUniform1i(Loc(S.pBlur, "uDepth"), 1);
        glUniform4f(Loc(S.pBlur, "uProj"), tanX, tanY, nearZ, farZ);
        glUniform1f(Loc(S.pBlur, "uMode"), (float)g_RGO.depthMode);
        glUniform1i(Loc(S.pBlur, "uAOTex"), 2);
        glUniform2f(Loc(S.pBlur, "uDir"), 1.0f / S.aoA.w, 0.0f);
        Tex(2, S.aoA.tex);
        Target(S.aoB);
        Draw();
        glUniform2f(Loc(S.pBlur, "uDir"), 0.0f, 1.0f / S.aoA.h);
        Tex(2, S.aoB.tex);
        Target(S.aoA);
        Draw();
    }

    // --- 4. Bloom
    if (useBloom)
    {
        Use(S.pPre);
        glUniform1i(Loc(S.pPre, "uSrc"), 0);
        Tex(0, S.sceneTex);
        glUniform2f(Loc(S.pPre, "uTexel"), 1.0f / sw, 1.0f / sh);
        glUniform2f(Loc(S.pPre, "uThr"), g_RGO.bloomThreshold, g_RGO.bloomKnee);
        Target(S.bloom[0]);
        Draw();

        Use(S.pDown);
        glUniform1i(Loc(S.pDown, "uSrc"), 0);
        GLint dTexel = Loc(S.pDown, "uTexel");
        for (int i = 1; i < S.bloomN; i++)
        {
            Tex(0, S.bloom[i - 1].tex);
            glUniform2f(dTexel, 1.0f / S.bloom[i - 1].w, 1.0f / S.bloom[i - 1].h);
            Target(S.bloom[i]);
            Draw();
        }

        Use(S.pUp);
        glUniform1i(Loc(S.pUp, "uSrc"), 0);
        glUniform1f(Loc(S.pUp, "uW"), 0.75f);
        GLint uTexel = Loc(S.pUp, "uTexel");
        glEnable(GL_BLEND);
        glBlendEquation(GL_FUNC_ADD);
        glBlendFunc(GL_ONE, GL_ONE);
        for (int i = S.bloomN - 1; i > 0; i--)
        {
            Tex(0, S.bloom[i].tex);
            glUniform2f(uTexel, 1.0f / S.bloom[i].w, 1.0f / S.bloom[i].h);
            Target(S.bloom[i - 1]);
            Draw();
        }
        glDisable(GL_BLEND);
    }

    // --- 5. Composite (+ optional FXAA/sharpen as a final pass)
    const bool finalPass = g_RGO.fxaa || g_RGO.sharpen > 0.0f || g_RGO.textureSmooth > 0.0f;

    float tod[8];
    TimeOfDay(tod);
    float wet = CWeather::WetRoads; if (CWeather::Rain > wet) wet = CWeather::Rain;
    if (wet < 0.0f) wet = 0.0f; if (wet > 1.0f) wet = 1.0f;
    wet = g_RGO.ssrDry + (1.0f - g_RGO.ssrDry) * wet;
    const bool ssrNow = g_RGO.ssr && S.depthOK;
    const bool fogNow = g_RGO.fog && S.depthOK;

    Use(S.pComp);
    Tex(0, S.sceneTex);
    Tex(2, S.aoA.tex);
    Tex(3, S.bloom[0].tex);
    glUniform1i(Loc(S.pComp, "uScene"), 0);
    glUniform1i(Loc(S.pComp, "uAOTex"), 2);
    glUniform1i(Loc(S.pComp, "uBloomTex"), 3);
    glUniform4f(Loc(S.pComp, "uFlags"), aoNow ? 1.0f : 0.0f, useBloom ? 1.0f : 0.0f, g_RGO.ssaoStrength, g_RGO.bloomIntensity);
    glUniform4f(Loc(S.pComp, "uGrade"), g_RGO.exposure * tod[3], g_RGO.tonemapMix, g_RGO.contrast, g_RGO.saturation);
    glUniform4f(Loc(S.pComp, "uTint"), tod[0], tod[1], tod[2], g_RGO.vignette);
    glUniform1i(Loc(S.pComp, "uDepth"), 1);
    Tex(1, S.depthTex);
    glUniform4f(Loc(S.pComp, "uProj"), tanX, tanY, nearZ, farZ);
    glUniform1f(Loc(S.pComp, "uMode"), (float)g_RGO.depthMode);
    glUniform2f(Loc(S.pComp, "uPx"), 1.0f / sw, 1.0f / sh);
    glUniform4f(Loc(S.pComp, "uX"), ssrNow ? 1.0f : 0.0f, wet, fogNow ? 1.0f : 0.0f, g_RGO.fogDensity);
    glUniform4f(Loc(S.pComp, "uSSR"), g_RGO.ssrStrength, (float)g_RGO.ssrSteps, g_RGO.ssrMaxDist, g_RGO.ssrThickness);
    glUniform1f(Loc(S.pComp, "uDbg"), (float)g_RGO.debugView);
    glUniform1f(Loc(S.pComp, "uLift"), g_RGO.shadowLift);
    glUniform1f(Loc(S.pComp, "uClarity"), g_RGO.clarity);
    glUniform4f(Loc(S.pComp, "uSplitS"), 0.90f, 0.98f, 1.08f, g_RGO.splitTone);
    glUniform4f(Loc(S.pComp, "uSplitH"), 1.08f, 1.01f, 0.88f, g_RGO.splitTone);
    glUniform4f(Loc(S.pComp, "uFogCol"), tod[4], tod[5], tod[6], g_RGO.fogStrength);
    if (!S.loggedRun) { S.loggedRun = true; RGO_LOGI("RGO pipeline running (ao=%d bloom=%d fxaa=%d)", (int)aoNow, (int)useBloom, (int)g_RGO.fxaa); }

    if (finalPass) Target(S.comp);
    else           { glBindFramebuffer(GL_FRAMEBUFFER, dstFbo); glViewport(0, 0, sw, sh); }
    if (!finalPass && g_RGO.splitCompare) { glEnable(GL_SCISSOR_TEST); glScissor(0, 0, sw / 2, sh); }
    Draw();
    glDisable(GL_SCISSOR_TEST);

    if (finalPass)
    {
        Use(S.pFXAA);
        Tex(0, S.comp.tex);
        glUniform1i(Loc(S.pFXAA, "uSrc"), 0);
        glUniform2f(Loc(S.pFXAA, "uTexel"), 1.0f / sw, 1.0f / sh);
        glUniform2f(Loc(S.pFXAA, "uOpt"), g_RGO.fxaa ? 1.0f : 0.0f, g_RGO.sharpen);
        glUniform1f(Loc(S.pFXAA, "uSmooth"), g_RGO.textureSmooth);
        glBindFramebuffer(GL_FRAMEBUFFER, dstFbo);
        glViewport(0, 0, sw, sh);
        if (g_RGO.splitCompare) { glEnable(GL_SCISSOR_TEST); glScissor(0, 0, sw / 2, sh); }
        Draw();
        glDisable(GL_SCISSOR_TEST);
    }

    GLenum err = glGetError();
    if (err != GL_NO_ERROR && !S.loggedFirst)
    {
        S.loggedFirst = true;
        RGO_LOGE("GL error 0x%X during RGO frame", err);
    }
    while (glGetError() != GL_NO_ERROR) {}

    {
        static int s_frames = 0;
        if (++s_frames % 900 == 1) RGO_LOGI("frame %d ok: %dx%d ao=%d bloom=%d ssr=%d fog=%d depthOK=%d", s_frames, sw, sh, (int)aoNow, (int)useBloom, (int)ssrNow, (int)fogNow, (int)S.depthOK);
    }
    Marker(0.0f, 1.0f, 0.0f);
    guard.Restore();
}

void RGO_Shutdown()
{
    S.failed = true;
}
