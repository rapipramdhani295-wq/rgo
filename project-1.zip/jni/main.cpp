#include <mod/amlmod.h>
#include <mod/logger.h>
#include <mod/config.h>
#include <dlfcn.h>
#include <EGL/egl.h>

#include <stdarg.h>
#include <stdio.h>
#include "rgo/rgo.h"
#include "rgo/rgo_hook.h"

MYMODCFG(net.rgo.realisticgraphics, Realistic Graphics Overhaul, 0.1, RGO)

void RGOFileLog(const char* fmt, ...)
{
    const char* dir = aml ? aml->GetAndroidDataPath() : NULL;
    char path[512];
    snprintf(path, sizeof(path), "%s/RGO_log.txt", dir ? dir : "/sdcard");
    FILE* f = fopen(path, "a");
    if (!f) return;
    va_list ap; va_start(ap, fmt);
    vfprintf(f, fmt, ap);
    va_end(ap);
    fputc('\n', f);
    fclose(f);
}

static EGLBoolean (*eglSwapBuffers_orig)(EGLDisplay, EGLSurface) = NULL;

static EGLBoolean HookOf_eglSwapBuffers(EGLDisplay dpy, EGLSurface surf)
{
    RGO_OnSwapBuffers((void*)dpy, (void*)surf);
    return eglSwapBuffers_orig(dpy, surf);
}

static bool  B(const char* k, bool d,  const char* sec) { ConfigEntry* e = cfg->Bind(k, d, sec); bool v = e->GetBool();  delete e; return v; }
static int   I(const char* k, int d,   const char* sec) { ConfigEntry* e = cfg->Bind(k, d, sec); int v = e->GetInt();     delete e; return v; }
static float F(const char* k, float d, const char* sec) { ConfigEntry* e = cfg->Bind(k, d, sec); float v = e->GetFloat(); delete e; return v; }

static void LoadConfig()
{
    cfg->Init();
    RGOSettings& s = g_RGO;
    s.enabled        = B("Enabled", s.enabled, "General");
    s.depthMode      = I("DepthMode", s.depthMode, "General");   // 0 = GL depth, 1 = D3D-style depth (try 1 if AO looks wrong)
    s.timeOfDayGrade = B("TimeOfDayGrade", s.timeOfDayGrade, "General");
    s.debugView      = I("DebugView", s.debugView, "General");
    s.splitCompare   = B("SplitCompare", s.splitCompare, "General");
    s.depthSource    = I("DepthSource", s.depthSource, "General");
    s.targetMode     = I("TargetMode", s.targetMode, "General");
    s.distanceBoost  = B("Enabled", s.distanceBoost, "Distance");
    s.lodScale       = F("LodScale", s.lodScale, "Distance");
    s.lowLodScale    = F("LowLodScale", s.lowLodScale, "Distance");
    s.drawDistScale  = F("DrawDistanceScale", s.drawDistScale, "Distance");
    s.whiteTextures  = B("WhiteTextures", s.whiteTextures, "Texture");
    s.whiteMinSize   = I("WhiteMinSize", s.whiteMinSize, "Texture");
    s.mipBias        = F("MipBias", s.mipBias, "Texture");
    s.maxMipLevel    = I("MaxMipLevel", s.maxMipLevel, "Texture");
    if (s.maxMipLevel > 8) s.maxMipLevel = 8;
    s.anisotropy     = I("Anisotropy", s.anisotropy, "Texture");
    if (s.anisotropy > 16) s.anisotropy = 16;
    if (s.mipBias < -2.0f) s.mipBias = -2.0f;
    if (s.mipBias > 1.0f) s.mipBias = 1.0f;
    s.textureLite    = B("TextureLite", s.textureLite, "Texture");
    s.textureMaxSize = I("MaxSize", s.textureMaxSize, "Texture");
    s.shaderDump     = B("ShaderDump", s.shaderDump, "Diagnostics");
    s.textureStats   = B("TextureStats", s.textureStats, "Diagnostics");
    s.debugMarker    = B("DebugMarker", s.debugMarker, "General");

    s.ssao           = B("Enabled", s.ssao, "SSAO");
    s.ssaoRadius     = F("Radius", s.ssaoRadius, "SSAO");
    s.ssaoIntensity  = F("Intensity", s.ssaoIntensity, "SSAO");
    s.ssaoBias       = F("Bias", s.ssaoBias, "SSAO");
    s.ssaoStrength   = F("Strength", s.ssaoStrength, "SSAO");
    s.ssaoFadeStart  = F("FadeStart", s.ssaoFadeStart, "SSAO");
    s.ssaoFadeEnd    = F("FadeEnd", s.ssaoFadeEnd, "SSAO");

    s.bloom          = B("Enabled", s.bloom, "Bloom");
    s.bloomThreshold = F("Threshold", s.bloomThreshold, "Bloom");
    s.bloomKnee      = F("Knee", s.bloomKnee, "Bloom");
    s.bloomIntensity = F("Intensity", s.bloomIntensity, "Bloom");
    s.bloomLevels    = I("Levels", s.bloomLevels, "Bloom");

    s.ssr            = B("Enabled", s.ssr, "SSR");
    s.ssrStrength    = F("Strength", s.ssrStrength, "SSR");
    s.ssrDry         = F("DryReflectivity", s.ssrDry, "SSR");
    s.ssrSteps       = I("Steps", s.ssrSteps, "SSR");
    if (s.ssrSteps > 32) s.ssrSteps = 32;
    if (s.ssrSteps < 4) s.ssrSteps = 4;
    s.ssrMaxDist     = F("MaxDistance", s.ssrMaxDist, "SSR");
    s.ssrThickness   = F("Thickness", s.ssrThickness, "SSR");

    s.fog            = B("Enabled", s.fog, "Atmosphere");
    s.fogDensity     = F("Density", s.fogDensity, "Atmosphere");
    s.fogStrength    = F("Strength", s.fogStrength, "Atmosphere");

    s.exposure       = F("Exposure", s.exposure, "Color");
    s.tonemapMix     = F("TonemapMix", s.tonemapMix, "Color");
    s.shadowLift     = F("ShadowLift", s.shadowLift, "Color");
    s.contrast       = F("Contrast", s.contrast, "Color");
    s.saturation     = F("Saturation", s.saturation, "Color");
    s.vignette       = F("Vignette", s.vignette, "Color");
    s.splitTone      = F("SplitTone", s.splitTone, "Color");

    s.contactShadow  = B("Enabled", s.contactShadow, "Shadow");
    s.shadowStrength = F("Strength", s.shadowStrength, "Shadow");
    s.shadowLen      = F("Length", s.shadowLen, "Shadow");
    s.shadowSteps    = I("Steps", s.shadowSteps, "Shadow");
    if (s.shadowSteps > 16) s.shadowSteps = 16;
    if (s.shadowSteps < 4) s.shadowSteps = 4;
    s.volumetric     = B("Enabled", s.volumetric, "Volumetric");
    s.volStrength    = F("Strength", s.volStrength, "Volumetric");
    s.volDensity     = F("Density", s.volDensity, "Volumetric");
    s.forceSun       = B("ForceSun", s.forceSun, "Volumetric");
    s.sunGlint       = B("Enabled", s.sunGlint, "SunGlint");
    s.glintStrength  = F("Strength", s.glintStrength, "SunGlint");
    s.wetAmount      = F("Amount", s.wetAmount, "Wet");
    s.wetDarken      = F("Darken", s.wetDarken, "Wet");

    s.fxaa           = B("FXAA", s.fxaa, "AA");
    s.sharpen        = F("Sharpen", s.sharpen, "AA");
    s.clarity        = F("Clarity", s.clarity, "AA");
    s.textureSmooth  = F("TextureSmooth", s.textureSmooth, "AA");
    cfg->Save();
}

ON_MOD_LOAD()
{
    logger->SetTag("RGO");
    RGOFileLog("---- RGO ON_MOD_LOAD ----");
    LoadConfig();
    if (!g_RGO.enabled) { RGO_LOGI("RGO disabled in config"); return; }

    void* hEGL = dlopen("libEGL.so", RTLD_NOW);
    void* fn = hEGL ? dlsym(hEGL, "eglSwapBuffers") : NULL;
    if (!fn) { RGO_LOGE("eglSwapBuffers not found"); return; }
    aml->Hook(fn, (void*)&HookOf_eglSwapBuffers, (void**)&eglSwapBuffers_orig);
    RGO_InstallGLHooks();
    RGO_LOGI("RGO %s loaded", BYBIT("32-bit", "64-bit"));
}
