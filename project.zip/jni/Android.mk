LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_CPP_EXTENSION := .cpp .cc
ifeq ($(TARGET_ARCH_ABI), armeabi-v7a)
    LOCAL_MODULE := RGO
else
    LOCAL_MODULE := RGO64
endif
LOCAL_SRC_FILES := main.cpp rgo/rgo_postfx.cpp mod/logger.cpp mod/config.cpp
LOCAL_C_INCLUDES += $(LOCAL_PATH)
LOCAL_CXXFLAGS += -O2 -DNDEBUG -std=c++17 -fno-exceptions -fno-rtti
ifeq ($(TARGET_ARCH_ABI), armeabi-v7a)
    LOCAL_CXXFLAGS += -mfloat-abi=softfp
endif
LOCAL_LDLIBS += -llog -lEGL -lGLESv3
include $(BUILD_SHARED_LIBRARY)
