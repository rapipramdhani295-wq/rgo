#include <mod/amlmod.h>
#include <mod/logger.h>
#include <mod/config.h>
#include <dlfcn.h>
#include <EGL/egl.h>

#include <stdarg.h>
#include <stdio.h>
#include "rgo/rgo.h"

MYMODCFG(net.rgo.realisticgraphics, Realistic Graphics Overhaul, 0.1, RGO)

void RGOFileLog(const char* fmt, ...)
{
    const char* dir = aml ? aml->GetAndroidDataPath() : NULL;
    char path[512];
    snprintf(path, sizeof(path), "%s/RGO_log.txt", dir ? dir : "/sdcard");
    FILE* f = fopen(path, "a");
    if (!f) return;
    va_list ap; va_start(ap, fmt);
    vfprintf(f, fmt, ap);
    va_end(ap);
    fputc('\n', f);
    fclose(f);
}

static EGLBoolean (*eglSwapBuffers_orig)(EGLDisplay, EGLSurface) = NULL;

static EGLBoolean HookOf_eglSwapBuffers(EGLDisplay dpy, EGLSurface surf)
{
    RGO_OnSwapBuffers((void*)dpy, (void*)surf);
    return eglSwapBuffers_orig(dpy, surf);
}

static bool  B(const char* k, bool d,  const char* sec) { ConfigEntry* e = cfg->Bind(k, d, sec); bool v = e->GetBool();  delete e; return v; }
static int   I(const char* k, int d,   const char* sec) { ConfigEntry* e = cfg->Bind(k, d, sec); int v = e->GetInt();     delete e; return v; }
static float F(const char* k, float d, const char* sec) { ConfigEntry* e = cfg->Bind(k, d, sec); float v = e->GetFloat(); delete e; return v; }

static void LoadConfig()
{
    cfg->Init();
    RGOSettings& s = g_RGO;
    s.enabled        = B("Enabled", s.enabled, "General");
    s.depthMode      = I("DepthMode", s.depthMode, "General");   // 0 = GL depth, 1 = D3D-style depth (try 1 if AO looks wrong)
    s.timeOfDayGrade = B("TimeOfDayGrade", s.timeOfDayGrade, "General");
    s.debugView      = I("DebugView", s.debugView, "General");
    s.splitCompare   = B("SplitCompare", s.splitCompare, "General");
    s.targetMode     = I("TargetMode", s.targetMode, "General");
    s.debugMarker    = B("DebugMarker", s.debugMarker, "General");

    s.ssao           = B("Enabled", s.ssao, "SSAO");
    s.ssaoRadius     = F("Radius", s.ssaoRadius, "SSAO");
    s.ssaoIntensity  = F("Intensity", s.ssaoIntensity, "SSAO");
    s.ssaoBias       = F("Bias", s.ssaoBias, "SSAO");
    s.ssaoStrength   = F("Strength", s.ssaoStrength, "SSAO");
    s.ssaoFadeStart  = F("FadeStart", s.ssaoFadeStart, "SSAO");
    s.ssaoFadeEnd    = F("FadeEnd", s.ssaoFadeEnd, "SSAO");

    s.bloom          = B("Enabled", s.bloom, "Bloom");
    s.bloomThreshold = F("Threshold", s.bloomThreshold, "Bloom");
    s.bloomKnee      = F("Knee", s.bloomKnee, "Bloom");
    s.bloomIntensity = F("Intensity", s.bloomIntensity, "Bloom");
    s.bloomLevels    = I("Levels", s.bloomLevels, "Bloom");

    s.ssr            = B("Enabled", s.ssr, "SSR");
    s.ssrStrength    = F("Strength", s.ssrStrength, "SSR");
    s.ssrDry         = F("DryReflectivity", s.ssrDry, "SSR");
    s.ssrSteps       = I("Steps", s.ssrSteps, "SSR");
    if (s.ssrSteps > 32) s.ssrSteps = 32;
    if (s.ssrSteps < 4) s.ssrSteps = 4;
    s.ssrMaxDist     = F("MaxDistance", s.ssrMaxDist, "SSR");
    s.ssrThickness   = F("Thickness", s.ssrThickness, "SSR");

    s.fog            = B("Enabled", s.fog, "Atmosphere");
    s.fogDensity     = F("Density", s.fogDensity, "Atmosphere");
    s.fogStrength    = F("Strength", s.fogStrength, "Atmosphere");

    s.exposure       = F("Exposure", s.exposure, "Color");
    s.tonemapMix     = F("TonemapMix", s.tonemapMix, "Color");
    s.contrast       = F("Contrast", s.contrast, "Color");
    s.saturation     = F("Saturation", s.saturation, "Color");
    s.vignette       = F("Vignette", s.vignette, "Color");
    s.splitTone      = F("SplitTone", s.splitTone, "Color");

    s.fxaa           = B("FXAA", s.fxaa, "AA");
    s.sharpen        = F("Sharpen", s.sharpen, "AA");
    cfg->Save();
}

ON_MOD_LOAD()
{
    logger->SetTag("RGO");
    RGOFileLog("---- RGO ON_MOD_LOAD ----");
    LoadConfig();
    if (!g_RGO.enabled) { RGO_LOGI("RGO disabled in config"); return; }

    void* hEGL = dlopen("libEGL.so", RTLD_NOW);
    void* fn = hEGL ? dlsym(hEGL, "eglSwapBuffers") : NULL;
    if (!fn) { RGO_LOGE("eglSwapBuffers not found"); return; }
    aml->Hook(fn, (void*)&HookOf_eglSwapBuffers, (void**)&eglSwapBuffers_orig);
    RGO_LOGI("RGO %s loaded", BYBIT("32-bit", "64-bit"));
}
