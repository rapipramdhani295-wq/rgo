#ifndef RGO_H
#define RGO_H

// Realistic Graphics Overhaul (RGO) - settings shared between main.cpp and the post-process pipeline.

struct RGOSettings
{
    // [General]
    bool  enabled        = true;
    int   depthMode      = 0;      // 0 = standard OpenGL depth (-1..1), 1 = D3D style (0..1)
    bool  timeOfDayGrade = true;
    int   debugView      = 0;      // 0 = normal, 1 = show depth, 2 = show SSAO
    bool  splitCompare   = true;   // only the LEFT half of the screen gets the effect (compare with the right half)
    int   targetMode     = 0;      // 0 = process default framebuffer, 1 = process the FBO bound at swap time
    bool  debugMarker    = true;   // small square top-left: blue = hook reached, green = pipeline ran

    // [SSAO]
    bool  ssao           = true;
    float ssaoRadius     = 1.5f;   // metres (view space)
    float ssaoIntensity  = 1.3f;
    float ssaoBias       = 0.04f;
    float ssaoFadeStart  = 60.0f;  // AO fades out between these distances
    float ssaoFadeEnd    = 140.0f;
    float ssaoStrength   = 0.92f;  // 0 = off, 1 = full multiply

    // [Bloom]
    bool  bloom          = true;
    float bloomThreshold = 0.70f;
    float bloomKnee      = 0.35f;
    float bloomIntensity = 0.30f;
    int   bloomLevels    = 5;

    // [SSR] screen-space reflections on upward-facing surfaces (roads, ground), stronger when wet
    bool  ssr            = true;
    float ssrStrength    = 0.9f;
    float ssrDry         = 0.25f;  // reflectivity when dry, 1.0 when raining / wet roads
    int   ssrSteps       = 16;     // max 32
    float ssrMaxDist     = 30.0f;
    float ssrThickness   = 0.8f;

    // [Atmosphere] depth fog tinted by time of day
    bool  fog            = true;
    float fogDensity     = 0.0035f;
    float fogStrength    = 0.45f;

    // [Color]
    float exposure       = 1.05f;
    float tonemapMix     = 0.60f;  // 0 = keep game look, 1 = full ACES
    float contrast       = 1.14f;
    float saturation     = 0.82f;
    float vignette       = 0.28f;
    float splitTone      = 0.55f;  // cool shadows / warm highlights (GTA IV look)

    // [AA]
    bool  fxaa           = true;
    float sharpen        = 0.45f;
};

extern RGOSettings g_RGO;

void RGO_OnSwapBuffers(void* eglDisplay, void* eglSurface); // call right before the real eglSwapBuffers
void RGO_Shutdown();
void RGOFileLog(const char* fmt, ...);   // appends to <android data path>/RGO_log.txt

#define RGO_LOGI(...) do { logger->Info(__VA_ARGS__); RGOFileLog(__VA_ARGS__); } while(0)
#define RGO_LOGE(...) do { logger->Error(__VA_ARGS__); RGOFileLog(__VA_ARGS__); } while(0)

#endif // RGO_H
