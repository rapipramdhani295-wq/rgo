// RGO phase 2a - GOT patching + game shader/texture dump.
//
// Patches the GOT/PLT slots of libGTASA.so (the same technique the RealWater log shows:
// "GOT slots patched: glDrawElements=1 glDrawArrays=1"). Nothing is changed in the game's rendering yet,
// we only *record* what the game does so phase 2b (lighting / shadows / light textures) is built on facts:
//   <android data>/RGO_shaders/*.txt   every unique GLSL source the game compiles
//   RGO_log.txt                        texture upload statistics

#include <mod/amlmod.h>
#include <mod/logger.h>

#include <link.h>
#include <elf.h>
#include <dlfcn.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <string>
#include <set>
#include <map>

#include "rgo.h"
#include "rgo_gl.h"
#include "rgo_hook.h"

extern Logger* logger;

// ------------------------------------------------------------------------------------------------
// GOT patcher
// ------------------------------------------------------------------------------------------------
#if defined(__LP64__)
    typedef Elf64_Rela  RelT;
    #define REL_TAG     DT_RELA
    #define REL_SZ_TAG  DT_RELASZ
    #define R_SYM(i)    ELF64_R_SYM(i)
#else
    typedef Elf32_Rel   RelT;
    #define REL_TAG     DT_REL
    #define REL_SZ_TAG  DT_RELSZ
    #define R_SYM(i)    ELF32_R_SYM(i)
#endif

struct FindLib { const char* name; uintptr_t base; const ElfW(Phdr)* phdr; int phnum; bool ok; };

static int PhdrCb(struct dl_phdr_info* info, size_t, void* data)
{
    FindLib* f = (FindLib*)data;
    if (info->dlpi_name && strstr(info->dlpi_name, f->name))
    {
        f->base = info->dlpi_addr; f->phdr = info->dlpi_phdr; f->phnum = info->dlpi_phnum; f->ok = true;
        return 1;
    }
    return 0;
}

static bool PatchTable(uintptr_t base, const RelT* rel, size_t bytes, const ElfW(Sym)* symtab, const char* strtab,
                       const char* symbol, void* newFn, void** origFn, int* count)
{
    const size_t page = (size_t)sysconf(_SC_PAGESIZE);
    for (size_t i = 0; i < bytes / sizeof(RelT); i++)
    {
        const char* nm = strtab + symtab[R_SYM(rel[i].r_info)].st_name;
        if (strcmp(nm, symbol) != 0) continue;
        void** slot = (void**)(base + rel[i].r_offset);
        void* pg = (void*)((uintptr_t)slot & ~(page - 1));
        mprotect(pg, page, PROT_READ | PROT_WRITE);
        if (origFn && !*origFn) *origFn = *slot;
        *slot = newFn;
        (*count)++;
    }
    return true;
}

bool RGO_GotHook(const char* lib, const char* symbol, void* newFn, void** origFn, int* slotsPatched)
{
    FindLib f = { lib, 0, NULL, 0, false };
    dl_iterate_phdr(PhdrCb, &f);
    if (!f.ok) return false;

    const ElfW(Dyn)* dyn = NULL;
    for (int i = 0; i < f.phnum; i++)
        if (f.phdr[i].p_type == PT_DYNAMIC) { dyn = (const ElfW(Dyn)*)(f.base + f.phdr[i].p_vaddr); break; }
    if (!dyn) return false;

    uintptr_t symtab = 0, strtab = 0, jmprel = 0, rel = 0;
    size_t jmprelSz = 0, relSz = 0;
    auto fix = [&](uintptr_t p) { return p < f.base ? p + f.base : p; };   // bionic keeps link-time addresses
    for (const ElfW(Dyn)* d = dyn; d->d_tag != DT_NULL; d++)
    {
        switch (d->d_tag)
        {
            case DT_SYMTAB:   symtab = fix(d->d_un.d_ptr); break;
            case DT_STRTAB:   strtab = fix(d->d_un.d_ptr); break;
            case DT_JMPREL:   jmprel = fix(d->d_un.d_ptr); break;
            case DT_PLTRELSZ: jmprelSz = d->d_un.d_val; break;
            case REL_TAG:     rel = fix(d->d_un.d_ptr); break;
            case REL_SZ_TAG:  relSz = d->d_un.d_val; break;
        }
    }
    if (!symtab || !strtab) return false;

    int count = 0;
    if (jmprel && jmprelSz) PatchTable(f.base, (const RelT*)jmprel, jmprelSz, (const ElfW(Sym)*)symtab, (const char*)strtab, symbol, newFn, origFn, &count);
    if (rel && relSz)       PatchTable(f.base, (const RelT*)rel, relSz, (const ElfW(Sym)*)symtab, (const char*)strtab, symbol, newFn, origFn, &count);
    if (slotsPatched) *slotsPatched = count;
    return count > 0;
}

// ------------------------------------------------------------------------------------------------
// Recorders
// ------------------------------------------------------------------------------------------------
static void (*o_glShaderSource)(GLuint, GLsizei, const GLchar* const*, const GLint*) = NULL;
static void (*o_glCompressedTexImage2D)(GLenum, GLint, GLenum, GLsizei, GLsizei, GLint, GLsizei, const void*) = NULL;
static void (*o_glTexImage2D)(GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum, const void*) = NULL;

static std::string g_shaderDir;
static std::set<size_t> g_seen;
static int g_shaderFiles = 0;

static void DumpShader(GLuint id, GLsizei count, const GLchar* const* str, const GLint* len)
{
    std::string src;
    for (GLsizei i = 0; i < count; i++)
    {
        if (!str[i]) continue;
        if (len && len[i] >= 0) src.append(str[i], (size_t)len[i]);
        else src.append(str[i]);
    }
    size_t h = std::hash<std::string>()(src);
    if (g_seen.count(h) || g_shaderFiles >= 400) return;
    g_seen.insert(h);

    char path[600];
    snprintf(path, sizeof(path), "%s/shader_%03d_id%u.txt", g_shaderDir.c_str(), g_shaderFiles++, id);
    FILE* f = fopen(path, "w");
    if (!f) return;
    fwrite(src.data(), 1, src.size(), f);
    fclose(f);
}

static void Hook_glShaderSource(GLuint shader, GLsizei count, const GLchar* const* str, const GLint* len)
{
    if (g_RGO.shaderDump && str) DumpShader(shader, count, str, len);
    o_glShaderSource(shader, count, str, len);
}

// texture statistics: key = (level0 width, height, format, compressed?)
struct TexKey { int w, h; unsigned fmt; bool comp; bool operator<(const TexKey& o) const {
    if (w != o.w) return w < o.w; if (h != o.h) return h < o.h; if (fmt != o.fmt) return fmt < o.fmt; return comp < o.comp; } };
static std::map<TexKey, int> g_tex;
static int g_texCalls = 0;
static long long g_texBytes = 0;

static void FlushTexStats()
{
    RGO_LOGI("texture stats after %d level-0 uploads, ~%lld KB:", g_texCalls, g_texBytes / 1024);
    int n = 0;
    for (auto& kv : g_tex)
    {
        if (n++ >= 40) break;
        RGO_LOGI("  %dx%d fmt=0x%X %s x%d", kv.first.w, kv.first.h, kv.first.fmt, kv.first.comp ? "compressed" : "raw", kv.second);
    }
}

static void CountTex(GLint level, GLsizei w, GLsizei h, unsigned fmt, bool comp, long long bytes)
{
    if (!g_RGO.textureStats) return;
    if (level == 0)
    {
        g_tex[{w, h, fmt, comp}]++;
        g_texCalls++;
        if (g_texCalls == 300 || g_texCalls == 1500 || g_texCalls == 4000) FlushTexStats();
    }
    g_texBytes += bytes;
}

static void Hook_glCompressedTexImage2D(GLenum t, GLint level, GLenum fmt, GLsizei w, GLsizei h, GLint b, GLsizei size, const void* data)
{
    if (t == GL_TEXTURE_2D) CountTex(level, w, h, fmt, true, size);
    o_glCompressedTexImage2D(t, level, fmt, w, h, b, size, data);
}

static void Hook_glTexImage2D(GLenum t, GLint level, GLint ifmt, GLsizei w, GLsizei h, GLint b, GLenum fmt, GLenum type, const void* data)
{
    if (t == GL_TEXTURE_2D) CountTex(level, w, h, (unsigned)ifmt, false, (long long)w * h * 4);
    o_glTexImage2D(t, level, ifmt, w, h, b, fmt, type, data);
}

void RGO_InstallGLHooks()
{
    if (!g_RGO.shaderDump && !g_RGO.textureStats) return;

    const char* dir = aml ? aml->GetAndroidDataPath() : NULL;
    g_shaderDir = std::string(dir ? dir : "/sdcard") + "/RGO_shaders";
    mkdir(g_shaderDir.c_str(), 0777);

    int a = 0, b = 0, c = 0;
    bool ok1 = RGO_GotHook("libGTASA", "glShaderSource",         (void*)&Hook_glShaderSource,         (void**)&o_glShaderSource, &a);
    bool ok2 = RGO_GotHook("libGTASA", "glCompressedTexImage2D", (void*)&Hook_glCompressedTexImage2D, (void**)&o_glCompressedTexImage2D, &b);
    bool ok3 = RGO_GotHook("libGTASA", "glTexImage2D",           (void*)&Hook_glTexImage2D,           (void**)&o_glTexImage2D, &c);
    RGO_LOGI("GOT hooks: glShaderSource=%d(%d) glCompressedTexImage2D=%d(%d) glTexImage2D=%d(%d)", (int)ok1, a, (int)ok2, b, (int)ok3, c);
}
