// RGO phase 2a - GOT patching + game shader/texture dump.
//
// Patches the GOT/PLT slots of libGTASA.so (the same technique the RealWater log shows:
// "GOT slots patched: glDrawElements=1 glDrawArrays=1"). Nothing is changed in the game's rendering yet,
// we only *record* what the game does so phase 2b (lighting / shadows / light textures) is built on facts:
//   <android data>/RGO_shaders/*.txt   every unique GLSL source the game compiles
//   RGO_log.txt                        texture upload statistics

#include <mod/amlmod.h>
#include <mod/logger.h>

#include <link.h>
#include <elf.h>
#include <dlfcn.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <string>
#include <set>
#include <map>
#include <vector>
#include <algorithm>

#include <aml-psdk/game_sa/engine/Renderer.h>
#include <aml-psdk/game_sa/engine/Draw.h>

#include "rgo.h"
#include "rgo_gl.h"
#include "rgo_hook.h"

extern Logger* logger;

// ------------------------------------------------------------------------------------------------
// GOT patcher
// ------------------------------------------------------------------------------------------------
#if defined(__LP64__)
    typedef Elf64_Rela  RelT;
    #define REL_TAG     DT_RELA
    #define REL_SZ_TAG  DT_RELASZ
    #define R_SYM(i)    ELF64_R_SYM(i)
#else
    typedef Elf32_Rel   RelT;
    #define REL_TAG     DT_REL
    #define REL_SZ_TAG  DT_RELSZ
    #define R_SYM(i)    ELF32_R_SYM(i)
#endif

struct FindLib { const char* name; uintptr_t base; const ElfW(Phdr)* phdr; int phnum; bool ok; };

static int PhdrCb(struct dl_phdr_info* info, size_t, void* data)
{
    FindLib* f = (FindLib*)data;
    if (info->dlpi_name && strstr(info->dlpi_name, f->name))
    {
        f->base = info->dlpi_addr; f->phdr = info->dlpi_phdr; f->phnum = info->dlpi_phnum; f->ok = true;
        return 1;
    }
    return 0;
}

static bool PatchTable(uintptr_t base, const RelT* rel, size_t bytes, const ElfW(Sym)* symtab, const char* strtab,
                       const char* symbol, void* newFn, void** origFn, int* count)
{
    const size_t page = (size_t)sysconf(_SC_PAGESIZE);
    for (size_t i = 0; i < bytes / sizeof(RelT); i++)
    {
        const char* nm = strtab + symtab[R_SYM(rel[i].r_info)].st_name;
        if (strcmp(nm, symbol) != 0) continue;
        void** slot = (void**)(base + rel[i].r_offset);
        void* pg = (void*)((uintptr_t)slot & ~(page - 1));
        mprotect(pg, page, PROT_READ | PROT_WRITE);
        if (origFn && !*origFn) *origFn = *slot;
        *slot = newFn;
        (*count)++;
    }
    return true;
}

bool RGO_GotHook(const char* lib, const char* symbol, void* newFn, void** origFn, int* slotsPatched)
{
    FindLib f = { lib, 0, NULL, 0, false };
    dl_iterate_phdr(PhdrCb, &f);
    if (!f.ok) return false;

    const ElfW(Dyn)* dyn = NULL;
    for (int i = 0; i < f.phnum; i++)
        if (f.phdr[i].p_type == PT_DYNAMIC) { dyn = (const ElfW(Dyn)*)(f.base + f.phdr[i].p_vaddr); break; }
    if (!dyn) return false;

    uintptr_t symtab = 0, strtab = 0, jmprel = 0, rel = 0;
    size_t jmprelSz = 0, relSz = 0;
    auto fix = [&](uintptr_t p) { return p < f.base ? p + f.base : p; };   // bionic keeps link-time addresses
    for (const ElfW(Dyn)* d = dyn; d->d_tag != DT_NULL; d++)
    {
        switch (d->d_tag)
        {
            case DT_SYMTAB:   symtab = fix(d->d_un.d_ptr); break;
            case DT_STRTAB:   strtab = fix(d->d_un.d_ptr); break;
            case DT_JMPREL:   jmprel = fix(d->d_un.d_ptr); break;
            case DT_PLTRELSZ: jmprelSz = d->d_un.d_val; break;
            case REL_TAG:     rel = fix(d->d_un.d_ptr); break;
            case REL_SZ_TAG:  relSz = d->d_un.d_val; break;
        }
    }
    if (!symtab || !strtab) return false;

    int count = 0;
    if (jmprel && jmprelSz) PatchTable(f.base, (const RelT*)jmprel, jmprelSz, (const ElfW(Sym)*)symtab, (const char*)strtab, symbol, newFn, origFn, &count);
    if (rel && relSz)       PatchTable(f.base, (const RelT*)rel, relSz, (const ElfW(Sym)*)symtab, (const char*)strtab, symbol, newFn, origFn, &count);
    if (slotsPatched) *slotsPatched = count;
    return count > 0;
}

// ------------------------------------------------------------------------------------------------
// Recorders
// ------------------------------------------------------------------------------------------------
static void (*o_glShaderSource)(GLuint, GLsizei, const GLchar* const*, const GLint*) = NULL;
static void (*o_glCompressedTexImage2D)(GLenum, GLint, GLenum, GLsizei, GLsizei, GLint, GLsizei, const void*) = NULL;
static void (*o_glTexImage2D)(GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum, const void*) = NULL;

static std::string g_shaderDir;
static std::set<size_t> g_seen;
static int g_shaderFiles = 0;

static void DumpShader(GLuint id, GLsizei count, const GLchar* const* str, const GLint* len)
{
    std::string src;
    for (GLsizei i = 0; i < count; i++)
    {
        if (!str[i]) continue;
        if (len && len[i] >= 0) src.append(str[i], (size_t)len[i]);
        else src.append(str[i]);
    }
    size_t h = std::hash<std::string>()(src);
    if (g_seen.count(h) || g_shaderFiles >= 400) return;
    g_seen.insert(h);

    char path[600];
    snprintf(path, sizeof(path), "%s/shader_%03d_id%u.txt", g_shaderDir.c_str(), g_shaderFiles++, id);
    FILE* f = fopen(path, "w");
    if (!f) return;
    fwrite(src.data(), 1, src.size(), f);
    fclose(f);
}

static bool IsIdentCh(char c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_'; }

// adds a texture LOD bias to every two-argument texture2D()/texture() call: far textures stay sharper
static int AddBias(std::string& s, const char* fn, const char* bias)
{
    const size_t fl = strlen(fn);
    int patched = 0;
    size_t pos = 0;
    while ((pos = s.find(fn, pos)) != std::string::npos)
    {
        if ((pos > 0 && IsIdentCh(s[pos - 1])) || pos + fl >= s.size() || s[pos + fl] != '(') { pos += fl; continue; }
        size_t i = pos + fl + 1;
        int depth = 1, commas = 0;
        while (i < s.size() && depth > 0)
        {
            char c = s[i];
            if (c == '(') depth++;
            else if (c == ')') { depth--; if (depth == 0) break; }
            else if (c == ',' && depth == 1) commas++;
            i++;
        }
        if (depth == 0 && commas == 1) { s.insert(i, std::string(", ") + bias); patched++; }
        pos += fl + 1;
    }
    return patched;
}

static void Hook_glShaderSource(GLuint shader, GLsizei count, const GLchar* const* str, const GLint* len)
{
    if (g_RGO.shaderDump && str) DumpShader(shader, count, str, len);
    if (g_RGO.mipBias != 0.0f && str && count > 0)
    {
        std::string src;
        for (GLsizei i = 0; i < count; i++)
        {
            if (!str[i]) continue;
            if (len && len[i] >= 0) src.append(str[i], (size_t)len[i]); else src.append(str[i]);
        }
        const bool vertex = src.find("gl_Position") != std::string::npos;
        if (!vertex && (src.find("texture2D(") != std::string::npos || src.find("texture(") != std::string::npos))
        {
            char bias[32];
            snprintf(bias, sizeof(bias), "(%.2f)", g_RGO.mipBias);
            int n = AddBias(src, "texture2D", bias);
            if (src.find("#version 3") != std::string::npos) n += AddBias(src, "texture", bias);
            if (n > 0)
            {
                static int s_logged = 0;
                if (s_logged < 3) { s_logged++; RGO_LOGI("MipBias %.2f applied to a shader (%d lookups)", g_RGO.mipBias, n); }
                const GLchar* one = src.c_str();
                GLint l = (GLint)src.size();
                o_glShaderSource(shader, 1, &one, &l);
                return;
            }
        }
    }
    o_glShaderSource(shader, count, str, len);
}

// anisotropic filtering: whenever the game sets a min filter, also request anisotropy
static void (*o_glTexParameteri)(GLenum, GLenum, GLint) = NULL;
static float s_maxAniso = -1.0f;
static void Hook_glTexParameteri(GLenum target, GLenum pname, GLint param)
{
    if (g_RGO.forceLinear)
    {
        if (pname == GL_TEXTURE_MAG_FILTER && param == GL_NEAREST) param = GL_LINEAR;
        else if (pname == GL_TEXTURE_MIN_FILTER && param == GL_NEAREST) param = GL_LINEAR;
        else if (pname == GL_TEXTURE_MIN_FILTER && param == GL_NEAREST_MIPMAP_NEAREST) param = GL_LINEAR_MIPMAP_LINEAR;
        else if (pname == GL_TEXTURE_MIN_FILTER && param == GL_LINEAR_MIPMAP_NEAREST) param = GL_LINEAR_MIPMAP_LINEAR;
    }
    o_glTexParameteri(target, pname, param);
    if (pname == GL_TEXTURE_MIN_FILTER && g_RGO.maxMipLevel >= 0 && target == GL_TEXTURE_2D)
        glTexParameteri(target, GL_TEXTURE_MAX_LEVEL, g_RGO.maxMipLevel);   // far textures never fall below this mip: no blur
    if (pname == GL_TEXTURE_MIN_FILTER && g_RGO.anisotropy > 1 && target == GL_TEXTURE_2D)
    {
        if (s_maxAniso < 0.0f) { s_maxAniso = 1.0f; glGetFloatv(0x84FF, &s_maxAniso); glGetError(); if (s_maxAniso < 1.0f) s_maxAniso = 1.0f; }
        float a = (float)g_RGO.anisotropy; if (a > s_maxAniso) a = s_maxAniso;
        if (a > 1.0f) glTexParameterf(target, 0x84FE, a);
    }
}

// texture statistics: key = (level0 width, height, format, compressed?)
struct TexKey { int w, h; unsigned fmt; bool comp; bool operator<(const TexKey& o) const {
    if (w != o.w) return w < o.w; if (h != o.h) return h < o.h; if (fmt != o.fmt) return fmt < o.fmt; return comp < o.comp; } };
static std::map<TexKey, int> g_tex;
static int g_texCalls = 0;
static long long g_texBytes = 0;

static void FlushTexStats()
{
    RGO_LOGI("texture stats after %d level-0 uploads, ~%lld KB:", g_texCalls, g_texBytes / 1024);
    int n = 0;
    for (auto& kv : g_tex)
    {
        if (n++ >= 40) break;
        RGO_LOGI("  %dx%d fmt=0x%X %s x%d", kv.first.w, kv.first.h, kv.first.fmt, kv.first.comp ? "compressed" : "raw", kv.second);
    }
}

static void CountTex(GLint level, GLsizei w, GLsizei h, unsigned fmt, bool comp, long long bytes)
{
    if (!g_RGO.textureStats) return;
    if (level == 0)
    {
        g_tex[{w, h, fmt, comp}]++;
        g_texCalls++;
        if (g_texCalls == 300 || g_texCalls == 1500 || g_texCalls == 4000) FlushTexStats();
    }
    g_texBytes += bytes;
}

// ---- TextureLite -------------------------------------------------------------------------------
// Big compressed textures are uploaded with their top mip level(s) dropped, so they use 1/4 (or 1/16) of the
// memory and bandwidth. A texture is only shrunk when the game really uploads a mip chain for it: level 0 is held
// back until level 1 shows up; a texture with a single level is uploaded untouched (no black textures).
static void (*o_glBindTexture)(GLenum, GLuint) = NULL;
static void (*o_glDrawElements)(GLenum, GLsizei, GLenum, const void*) = NULL;
static void (*o_glDrawArrays)(GLenum, GLint, GLsizei) = NULL;

struct Pending { bool active = false; GLuint tex = 0; GLenum fmt = 0; GLsizei w = 0, h = 0, size = 0; std::vector<unsigned char> data; };
static Pending g_pend;
static std::map<GLuint, int> g_shift;      // texture id -> number of dropped top levels
static long long g_savedBytes = 0;
static int g_shrunk = 0, g_untouched = 0;

static void FlushPending()
{
    if (!g_pend.active) return;
    g_pend.active = false;
    GLint prev = 0;
    glGetIntegerv(GL_TEXTURE_BINDING_2D, &prev);
    o_glBindTexture(GL_TEXTURE_2D, g_pend.tex);
    o_glCompressedTexImage2D(GL_TEXTURE_2D, 0, g_pend.fmt, g_pend.w, g_pend.h, 0, g_pend.size, g_pend.data.data());
    o_glBindTexture(GL_TEXTURE_2D, (GLuint)prev);
    g_untouched++;
}

void RGO_FlushPendingTex() { FlushPending(); }

static void Hook_glBindTexture(GLenum target, GLuint tex)
{
    if (g_pend.active && !(target == GL_TEXTURE_2D && tex == g_pend.tex)) FlushPending();
    o_glBindTexture(target, tex);
}
static void Hook_glDrawElements(GLenum m, GLsizei c, GLenum t, const void* i) { if (g_pend.active) FlushPending(); o_glDrawElements(m, c, t, i); }
static void Hook_glDrawArrays(GLenum m, GLint f, GLsizei c)                   { if (g_pend.active) FlushPending(); o_glDrawArrays(m, f, c); }

// ---- WhiteTextures -----------------------------------------------------------------------------
// Opaque (RGB-only) compressed textures of at least WhiteMinSize pixels are replaced by a single white texel.
// Formats with an alpha channel (leaves, fences, fonts, HUD sprites) are never touched, so they keep their shape.
static std::set<GLuint> g_white;
static int g_whiteCount = 0;

static bool IsRgbOnly(GLenum fmt)
{
    switch (fmt)
    {
        case 0x83F0:    // S3TC DXT1 RGB
        case 0x8D64:    // ETC1 RGB8
        case 0x9274:    // ETC2 RGB8
        case 0x8C00:    // PVRTC 4bpp RGB
        case 0x8C01:    // PVRTC 2bpp RGB
        case 0x8C92:    // ATC RGB
            return true;
    }
    return false;
}

static void Hook_glCompressedTexImage2D(GLenum t, GLint level, GLenum fmt, GLsizei w, GLsizei h, GLint b, GLsizei size, const void* data)
{
    if (t == GL_TEXTURE_2D) CountTex(level, w, h, fmt, true, size);

    if (g_RGO.whiteTextures && t == GL_TEXTURE_2D && o_glTexImage2D && IsRgbOnly(fmt))
    {
        GLint wcur = 0;
        glGetIntegerv(GL_TEXTURE_BINDING_2D, &wcur);
        if (level == 0)
        {
            FlushPending();
            g_white.erase((GLuint)wcur);
            if (std::max(w, h) >= g_RGO.whiteMinSize)
            {
                static const unsigned char px[4] = { 255, 255, 255, 255 };
                o_glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, 1, 1, 0, GL_RGB, GL_UNSIGNED_BYTE, px);
                g_white.insert((GLuint)wcur);
                if (++g_whiteCount == 50 || g_whiteCount == 400 || g_whiteCount == 1500)
                    RGO_LOGI("WhiteTextures: %d textures replaced", g_whiteCount);
                return;
            }
        }
        else if (g_white.count((GLuint)wcur)) return;     // higher mips of a replaced texture
    }

    if (!g_RGO.textureLite || t != GL_TEXTURE_2D || !data || size <= 0)
    {
        FlushPending();
        o_glCompressedTexImage2D(t, level, fmt, w, h, b, size, data);
        return;
    }

    GLint cur = 0;
    glGetIntegerv(GL_TEXTURE_BINDING_2D, &cur);

    if (level == 0)
    {
        FlushPending();
        g_shift.erase((GLuint)cur);
        const int cap = g_RGO.textureMaxSize < 64 ? 64 : g_RGO.textureMaxSize;
        if (std::max(w, h) > cap && std::min(w, h) >= 16)
        {
            g_pend.active = true; g_pend.tex = (GLuint)cur; g_pend.fmt = fmt; g_pend.w = w; g_pend.h = h; g_pend.size = size;
            g_pend.data.assign((const unsigned char*)data, (const unsigned char*)data + size);
            return;     // wait for level 1
        }
        o_glCompressedTexImage2D(t, level, fmt, w, h, b, size, data);
        return;
    }

    if (g_pend.active && g_pend.tex == (GLuint)cur)
    {
        // a mip chain really follows -> shrink
        const int cap = g_RGO.textureMaxSize < 64 ? 64 : g_RGO.textureMaxSize;
        int k = 0, d = std::max(g_pend.w, g_pend.h);
        while (d > cap && k < 3) { d >>= 1; k++; }
        g_shift[(GLuint)cur] = k;
        g_savedBytes += g_pend.size;
        g_shrunk++;
        g_pend.active = false;
        if (g_shrunk == 50 || g_shrunk == 400 || g_shrunk == 1500)
            RGO_LOGI("TextureLite: %d textures shrunk, level-0 data skipped ~%lld KB, %d left untouched", g_shrunk, g_savedBytes / 1024, g_untouched);
    }

    auto it = g_shift.find((GLuint)cur);
    int k = (it == g_shift.end()) ? 0 : it->second;
    if (k > 0)
    {
        if (level < k) return;                      // dropped level
        level -= k;
    }
    o_glCompressedTexImage2D(t, level, fmt, w, h, b, size, data);
}

static void Hook_glTexImage2D(GLenum t, GLint level, GLint ifmt, GLsizei w, GLsizei h, GLint b, GLenum fmt, GLenum type, const void* data)
{
    if (t == GL_TEXTURE_2D) CountTex(level, w, h, (unsigned)ifmt, false, (long long)w * h * 4);
    if (g_pend.active) FlushPending();
    o_glTexImage2D(t, level, ifmt, w, h, b, fmt, type, data);
}

// ------------------------------------------------------------------------------------------------
// Draw distance / LOD boost: objects stay detailed and visible farther away.
// Values are captured once and then set absolutely (base * scale), so they never compound frame after frame.
// ------------------------------------------------------------------------------------------------
static void (*o_ConstructRenderList)() = NULL;
static float g_baseLod = 0.0f, g_baseLowLod = 0.0f, g_baseDraw = 0.0f;
static bool  g_baseTaken = false;
static bool  g_distLogged = false;

static void Hook_ConstructRenderList()
{
    if (g_RGO.distanceBoost)
    {
        float& lod    = CRenderer::ms_lodDistScale;
        float& lowLod = CRenderer::ms_lowLodDistScale;
        float& draw   = CDraw::ms_fLODDistance;
        if (!g_baseTaken && lod > 0.0f)
        {
            g_baseLod = lod; g_baseLowLod = lowLod; g_baseDraw = draw;
            g_baseTaken = true;
            RGO_LOGI("Distance boost base values: lodDistScale=%.3f lowLodDistScale=%.3f lodDistance=%.1f", g_baseLod, g_baseLowLod, g_baseDraw);
        }
        if (g_baseTaken)
        {
            lod    = g_baseLod    * g_RGO.lodScale;
            lowLod = g_baseLowLod * g_RGO.lowLodScale;
            draw   = g_baseDraw   * g_RGO.drawDistScale;
            if (!g_distLogged) { g_distLogged = true; RGO_LOGI("Distance boost active (x%.2f / x%.2f / x%.2f)", g_RGO.lodScale, g_RGO.lowLodScale, g_RGO.drawDistScale); }
        }
    }
    o_ConstructRenderList();
}

static void InstallDistanceHook()
{
    if (!g_RGO.distanceBoost) return;
    void* fn = (void*)aml->GetSym(GetMainLibrary(), "_ZN9CRenderer19ConstructRenderListEv");
    if (!fn) { RGO_LOGE("Distance boost: CRenderer::ConstructRenderList not found"); return; }
    aml->Hook(fn, (void*)&Hook_ConstructRenderList, (void**)&o_ConstructRenderList);
    RGO_LOGI("Distance boost hook installed");
}

void RGO_InstallGLHooks()
{
    InstallDistanceHook();

    if (!g_RGO.shaderDump && !g_RGO.textureStats && !g_RGO.textureLite && !g_RGO.whiteTextures && g_RGO.mipBias == 0.0f && g_RGO.anisotropy <= 1 && g_RGO.maxMipLevel < 0 && !g_RGO.forceLinear) return;

    const char* dir = aml ? aml->GetAndroidDataPath() : NULL;
    g_shaderDir = std::string(dir ? dir : "/sdcard") + "/RGO_shaders";
    mkdir(g_shaderDir.c_str(), 0777);

    int a = 0, b = 0, c = 0;
    bool ok1 = RGO_GotHook("libGTASA", "glShaderSource",         (void*)&Hook_glShaderSource,         (void**)&o_glShaderSource, &a);
    bool ok2 = RGO_GotHook("libGTASA", "glCompressedTexImage2D", (void*)&Hook_glCompressedTexImage2D, (void**)&o_glCompressedTexImage2D, &b);
    bool ok3 = RGO_GotHook("libGTASA", "glTexImage2D",           (void*)&Hook_glTexImage2D,           (void**)&o_glTexImage2D, &c);
    if (g_RGO.anisotropy > 1 || g_RGO.maxMipLevel >= 0 || g_RGO.forceLinear)
    {
        int g2 = 0;
        bool okt = RGO_GotHook("libGTASA", "glTexParameteri", (void*)&Hook_glTexParameteri, (void**)&o_glTexParameteri, &g2);
        RGO_LOGI("Anisotropy x%d MaxMipLevel %d hook=%d(%d)", g_RGO.anisotropy, g_RGO.maxMipLevel, (int)okt, g2);
    }
    int d = 0, e = 0, f = 0;
    if (g_RGO.textureLite)
    {
        bool okb = RGO_GotHook("libGTASA", "glBindTexture",  (void*)&Hook_glBindTexture,  (void**)&o_glBindTexture, &d);
        bool oke = RGO_GotHook("libGTASA", "glDrawElements", (void*)&Hook_glDrawElements, (void**)&o_glDrawElements, &e);
        bool okf = RGO_GotHook("libGTASA", "glDrawArrays",   (void*)&Hook_glDrawArrays,   (void**)&o_glDrawArrays, &f);
        if (!(okb && oke && okf && ok2))
        {
            // without all the hooks the "hold level 0" logic is unsafe: turn the feature off
            RGO_LOGE("TextureLite needs glBindTexture/glDrawElements/glDrawArrays/glCompressedTexImage2D hooks (%d %d %d %d); disabled", (int)okb, (int)oke, (int)okf, (int)ok2);
            g_RGO.textureLite = false;
        }
    }
    RGO_LOGI("GOT hooks: glShaderSource=%d(%d) glCompressedTexImage2D=%d(%d) glTexImage2D=%d(%d)", (int)ok1, a, (int)ok2, b, (int)ok3, c);
}
