#ifndef RGO_GL_H
#define RGO_GL_H

#include <GLES3/gl3.h>
#include <GLES3/gl31.h>
#include <GLES3/gl3ext.h>
#include <EGL/egl.h>

struct RGORT
{
    GLuint tex = 0, fbo = 0;
    int w = 0, h = 0;
};

// Saves/restores every piece of GL state we touch. The game's render queue caches its own
// state, so anything we change MUST be put back exactly.
struct GLStateGuard
{
    GLint program, drawFbo, readFbo, vao, activeTex, viewport[4], scissor[4];
    GLint tex2D[4];
    GLboolean blend, depthTest, cull, scissorTest, stencilTest, dither;
    GLboolean colorMask[4], depthMask;
    GLint blendSrcRGB, blendDstRGB, blendSrcA, blendDstA, blendEqRGB, blendEqA;

    void Save();
    void Restore();
};

#endif // RGO_GL_H
