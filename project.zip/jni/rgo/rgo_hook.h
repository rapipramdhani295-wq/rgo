#ifndef RGO_HOOK_H
#define RGO_HOOK_H

// Phase 2: patch libGTASA's GOT so we see the game's own GL calls (shaders, textures, draws).
bool RGO_GotHook(const char* lib, const char* symbol, void* newFn, void** origFn, int* slotsPatched);
void RGO_InstallGLHooks();
void RGO_FlushPendingTex();

#endif
