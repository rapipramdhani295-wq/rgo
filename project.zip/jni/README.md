# RGO fase 1 (post-process, GLES 3.0+)
Tempel isi folder ini ke folder `jni/` Anda (timpa `main.cpp`, `Android.mk`; folder `rgo/` baru).
Build: `ndk-build` (armeabi-v7a dulu, arm64-v8a menyusul). Hasil: `libRGO.so` / `libRGO64.so` -> folder mods AML.
Config otomatis dibuat oleh AML (RGO.ini). Log tag: `RGO` (cek logcat/AML log).

Jika AO terlihat salah / hitam: ubah `DepthMode` 0 <-> 1.
